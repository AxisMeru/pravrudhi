"""Delegating development work to the agent fleet, safely.

Several agents improving one repository is useful only if their work cannot collide or slip in unvalidated. Three
guarantees are enforced here rather than trusted to the agents or to whoever wrote the prompt.

Disjoint ownership: a task declares the paths it may touch, and two tasks that could touch the same path are never
dispatched together. Agents cannot overwrite each other because they are never given overlapping ground, and each
works in its own worktree besides.

Declared scope: after the run the diff is checked against the declaration. An agent that edited something it was
not given is rejected whole, not partially merged, because a diff that wandered is evidence the agent misunderstood
the task rather than a diff with one stray file in it.

Validation before merge: the task's own check runs inside the worktree, and only a passing, in-scope,
protected-path-clean diff is eligible. Nothing reaches the working tree because an agent said it was finished.
"""

from __future__ import annotations

import fnmatch
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from pravrudhi.agents.base import SCRATCH_DIRNAME, Diff
from pravrudhi.application import availability


@dataclass(frozen=True)
class TaskSpec:
    """One unit of delegated work: what to do, where it may write, and how it is checked."""

    task_id: str
    prompt: str
    allowed_paths: tuple[str, ...]
    validate: str = "uv run pytest -q"
    timeout_s: int = 1800

    def owns(self, path: str) -> bool:
        """A declared path is a glob, or a directory when it ends in `/`.

        `fnmatch` alone treated `app/frontend/src/app/progress/` as a literal name, so a task handed a directory
        wrote every file inside it and was rejected for escaping its own scope; the work was correct and the
        detector was wrong.
        """
        for pat in self.allowed_paths:
            if pat.endswith("/") and path.startswith(pat):
                return True
            if fnmatch.fnmatch(path, pat):
                return True
        return False

    def out_of_scope(self, diff: Diff) -> list[str]:
        """Every file the diff touches that this task did not declare - except `SCRATCH_DIRNAME`, which is
        never in `allowed_paths` yet is exactly what `dispatch`'s own brief tells the agent it may write to
        (see the `SCRATCH_DIRNAME/**` entry in its "ONLY these paths" line). A tool the agent ran there (`uv`
        writing a lock file into `.pravrudhi-scratch/`, say) can end up committed before `dispatch` deletes the
        directory from disk, and a diff taken against that commit still shows it - rejecting an otherwise
        correct deliverable for exactly the scratch use the prompt promised. This is deliberately narrower than
        widening `owns()`: `owns()` also drives `dispatch`'s own main-checkout escape detector, which must keep
        treating a file outside the worktree as an escape regardless of its name.
        """
        def in_scratch(path: str) -> bool:
            return path == SCRATCH_DIRNAME or path.startswith(f"{SCRATCH_DIRNAME}/")

        return sorted(f for f in diff.files if not self.owns(f) and not in_scratch(f))


@dataclass(frozen=True)
class Verdict:
    task_id: str
    agent: str
    accepted: bool
    reasons: list[str] = field(default_factory=list)
    files: list[str] = field(default_factory=list)
    validation_output: str = ""
    wall_s: float = 0.0
    tokens: int | None = None
    """What the dispatch consumed, or `None` when the seat could not tell. Not coerced to zero: the whole
    difficulty was that an unmeasured dispatch and a free one shared a value."""

    cost_usd: float | None = None
    cache_read_tokens: int | None = None
    cache_write_tokens: int | None = None
    """What the dispatch consumed, carried up from the agent so the router can budget. Zero means the adapter
    could not tell, never that the work was free."""

    limited: bool = False
    resets_at: str = ""
    """When the vendor said the account comes back, ISO-8601 in UTC, empty when it did not say. Parsed here for
    the same reason `limited` is: this is where the agent's whole output is still in hand."""
    """Set when the agent failed because its account is spent rather than because the work was wrong.

    It is decided here, where the agent's whole output is still in hand. The swarm used to infer it from the
    rejection reason, which carries the first 200 characters of a 2000-character tail — and a vendor prints
    "you've hit your usage limit" at the *end* of a run, after echoing the prompt. So the one message that
    should have moved the task to another route was the one guaranteed to be truncated away, and the fallback
    never fired on the failure it exists for."""

    def to_dict(self) -> dict[str, Any]:
        return {
            "task_id": self.task_id, "agent": self.agent, "accepted": self.accepted,
            "reasons": self.reasons, "files": self.files, "wall_s": round(self.wall_s, 1),
        }


def overlapping(tasks: list[TaskSpec]) -> list[tuple[str, str]]:
    """Pairs of tasks whose declared paths could collide.

    Compared pattern against pattern, not file against file: two tasks that both claim `src/pravrudhi/cli/*` are in
    conflict even if today they would happen to edit different files there.
    """
    bad: list[tuple[str, str]] = []
    for i, a in enumerate(tasks):
        for b in tasks[i + 1 :]:
            collide = any(
                fnmatch.fnmatch(pa, pb) or fnmatch.fnmatch(pb, pa) or pa == pb
                for pa in a.allowed_paths
                for pb in b.allowed_paths
            )
            if collide:
                bad.append((a.task_id, b.task_id))
    return bad


def validate_in(workspace: Path, command: str, timeout_s: int = 1800) -> tuple[bool, str]:
    try:
        p = subprocess.run(["bash", "-lc", command], cwd=workspace, capture_output=True, text=True, timeout=timeout_s)
        return p.returncode == 0, (p.stdout + p.stderr)[-4000:]
    except subprocess.TimeoutExpired:
        return False, f"validation timed out after {timeout_s}s"


def _tree_state(root: Path) -> set[str]:
    """Uncommitted paths in a checkout, so a change made there during a dispatch can be told from one made before.

    `-uall` is load-bearing. By default `git status --porcelain` collapses an untracked directory to one entry, so
    a deliverable written into the main checkout appears as `proposals/probe/` rather than as the file itself. A
    task declares its scope as globs over files, which no directory name can match, so the escape was invisible
    and the verdict read "no change produced" - the same sentence as the incident this check was added for. Every
    real escape creates a new directory, because a proposal's first file always does.
    """
    try:
        p = subprocess.run(["git", "status", "--porcelain", "-uall"], cwd=root, capture_output=True, text=True,
                           timeout=60)
    except (OSError, subprocess.SubprocessError):
        return set()
    return {ln[3:] for ln in p.stdout.splitlines() if ln.strip()}


def dispatch(agent: Any, task: TaskSpec, *, log: Any = print) -> Verdict:
    """Run one task with one agent and judge the result. The worktree is left in place when accepted, so the
    change can be inspected and merged deliberately; a rejected worktree is also kept, because a rejected diff is
    the most interesting thing to read."""
    # The scratch entry is named IN the same "ONLY these paths" line, not a separate sentence elsewhere in the
    # brief -- a careful agent reading a stricter, later restriction ("only these paths") after an earlier,
    # separate permission ("use this directory") reads the two as contradictory and obeys the stricter one,
    # which is exactly how the incident this fixes happened in the first place. `ALLOWED_PATHS_LINE` in
    # loop_agent.py/hosted_agent.py also parses this exact sentence with a regex to learn what a non-Claude-
    # Code agent may write, so the scratch entry must be a clean comma-separated token in that same list, not
    # prose folded into it -- otherwise their parser either misses it or corrupts the whole parsed list.
    brief = (
        f"{task.prompt}\n\nYou may create or modify ONLY these paths: "
        f"{', '.join((*task.allowed_paths, f'{SCRATCH_DIRNAME}/**'))}.\n"
        f"`{SCRATCH_DIRNAME}/**` in that list is scratch or temporary space only, not part of your deliverable, "
        "and is discarded after this run -- everything else in the list is what you may actually change. Do "
        "not modify any other file, do not touch pravrudhi_kernel/, research/, gates/ or .pravrudhi/, and do "
        "not write to `/tmp` or any other path outside your worktree.\n"
        "Write every file relative to your current working directory, which is your own worktree; never write to "
        "an absolute path in the main checkout, even when the task quotes one to tell you what to read.\n"
        f"Your work is accepted only if `{task.validate}` passes."
    )
    ws = agent.create_workspace(task.task_id)
    root = Path(getattr(agent, "root", ws))
    before = _tree_state(root) if root != ws else set()
    scratch_dir = ws / SCRATCH_DIRNAME
    scratch_dir.mkdir(parents=True, exist_ok=True)
    log(f"{task.task_id}: {agent.name} working in {ws}")
    run = agent.run(brief, ws, timeout_s=task.timeout_s)
    shutil.rmtree(scratch_dir, ignore_errors=True)
    diff = agent.collect_changes(ws)
    reasons: list[str] = []
    appeared = sorted(_tree_state(root) - before) if root != ws else []
    # Only a path the task itself owns counts as an escape: that is the observed failure mode (an agent writing
    # its deliverable into the main checkout). The operator edits main while waves run, and the first form of this
    # check blamed two agents for files the operator had changed in unrelated modules.
    escaped = [f for f in appeared if task.owns(f)]
    if escaped:
        # Two agents once wrote their whole deliverable into the main checkout instead of their worktree, because
        # the task quoted absolute paths under it. Their worktrees were empty, so they were recorded as having
        # produced nothing, and the files were swept into the next commit unreviewed. The worktree diff cannot see
        # this; only the main tree can.
        reasons.append(f"wrote outside its worktree, into the main checkout: {', '.join(escaped[:8])}")
    limited, resets_at = False, ""
    if not run.ok:
        # The end of the tail, not the beginning: a run that fails ends with its reason and starts with an echo
        # of the prompt it was given.
        tail = (run.stderr_tail or "").strip()
        if not tail:
            # ClaudeCodeAgent reports its own errors via a JSON envelope on stdout (`is_error:
            # true`), which forces ok=False while the real explanation lands in `envelope.get(
            # "result", out)` -> run.text, not stderr_tail (raw process stderr, legitimately
            # empty for this failure mode -- claude's CLI doesn't write its own errors there).
            tail = (run.text or "").strip()
        reasons.append(f"agent exited non-zero: {tail[-200:] or 'no detail'}")
        whole = f"{tail}\n{run.text or ''}"
        limited = availability.classify(agent.name, whole, 1) == "limited"
        when = availability.reset_at(whole) if limited else None
        resets_at = when.strftime("%Y-%m-%dT%H:%M:%SZ") if when else ""
    if diff.empty:
        # A run that produced nothing is not always a run that did nothing: an agent that correctly refused to
        # fabricate the operator's own words, or that hit a scope it could not act inside, says so in its final
        # message. r-799f8dfb c0 (2026-09-12) was exactly that -- a criterion asking for the operator's verbatim
        # answers to questions nobody had asked yet, an agent that said so and stopped rather than invent them,
        # and a verdict that recorded only the generic string below, indistinguishable from an agent that had
        # simply done nothing at all.
        explanation = (run.text or "").strip()
        reasons.append(f"no change produced: {explanation[-1000:]}" if explanation else "no change produced")
    if diff.violations:
        reasons.append(f"touched protected paths: {', '.join(diff.violations)}")
    stray = task.out_of_scope(diff)
    if stray:
        reasons.append(f"wrote outside its declared scope: {', '.join(stray[:8])}")
    output = ""
    if not reasons:
        ok, output = validate_in(ws, task.validate, task.timeout_s)
        if not ok:
            reasons.append("validation failed")
    verdict = Verdict(
        task_id=task.task_id, agent=agent.name, accepted=not reasons, reasons=reasons,
        files=diff.files, validation_output=output[-2000:], wall_s=run.wall_s,
        tokens=getattr(run, "tokens", None), cost_usd=getattr(run, "cost_usd", None),
        cache_read_tokens=getattr(run, "cache_read_tokens", None),
        cache_write_tokens=getattr(run, "cache_write_tokens", None),
        limited=limited, resets_at=resets_at,
    )
    log(f"{task.task_id}: {'ACCEPTED' if verdict.accepted else 'REJECTED'} ({'; '.join(reasons) or 'all checks passed'})")
    return verdict
