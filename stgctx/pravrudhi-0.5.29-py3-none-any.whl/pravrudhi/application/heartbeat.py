"""OpenClaw's heartbeat: an assistant that wakes on a schedule, looks at what it wants, and does the next small
thing about it.

Every other way this engine moves is a command a user typed: `pravrudhi intent`, `pravrudhi subagents dispatch`,
`pravrudhi update apply`. Objectives (`application/objectives.py`) can sit fully planned and fully unstarted
forever, because a plan (`application/intent.py`) is not itself an action, and nothing here previously turned one
into the other without an operator's keystroke. A heartbeat closes that gap: one wake-up measures the engine's six
drives (`application/kshudha.py`), lets them select which one is largest and eligible, and dispatches the one
action that addresses that drive — through the same swarm machinery a human would use (`application/subagents.py`,
`application/swarm.py`), under the same proposal sandbox policy (`application/sandbox_policy.py`), when the
winning drive has a wired action at all.

`kshudha.select` only decides; it never dispatches (its own module docstring says so). This module is what turns
that decision into work: `samarthya` (capability) still runs the original objective-step dispatch; `seva`
(obligations) dispatches the oldest unmet request criterion; `sthiti` (continuity) proposes the cheapest failing
doctor check's remedy; `sadhana` (resources) has no route to dispatch to, so it records its desire once and steps
aside for the next eligible drive rather than dispatching a doomed route; `pramana_navyata` (freshness) and
`unnati_avakasha` (benchmark headroom) have no wired action in this codebase, so they always produce a bounded
diagnostic, never a fabricated one.

A beat that finds nothing to do, or is not allowed to do it, is still a beat: it is recorded with the reason,
because a heartbeat that only logs when it acts cannot be told apart from one that stopped ticking. Nothing here
writes to the ledger, `research/`, `gates/` or `pravrudhi_kernel/` — a dispatched step produces a proposal exactly
as it would under manual dispatch, for a human to review and execute.
"""

from __future__ import annotations

import contextlib
import json
import os
import re
import subprocess
from collections.abc import Callable
from dataclasses import dataclass, replace
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

import yaml

from pravrudhi.agents.registry import build_agent as _registry_build_agent
from pravrudhi.application import availability, kshudha, recipes, requests, subagents, swarm
from pravrudhi.application.delegate import TaskSpec
from pravrudhi.application.intent import compile_intent
from pravrudhi.application.objectives import load_all
from pravrudhi.application.sandbox_policy import Policy, apply_policy, policy_for
from pravrudhi.application.update_apply import run_in_progress

PACKAGED_CONFIG = Path(__file__).resolve().parents[1] / "assets" / "configs" / "heartbeat.yaml"

# Capabilities whose step trains or intensively exercises a model on the GPU that a live night has already
# claimed. Evaluation, corpus curation, retrieval, safety review and harness (agents) steps only ever produce a
# proposal document for a human to review and run (see application/subagents.py's module docstring), so those may
# proceed unattended; the ones here would actually compete for the hardware.
GPU_CAPABILITIES: frozenset[str] = frozenset({"pretrain", "finetune", "rl", "performance"})

BuildAgentFn = Callable[[str, str | None], Any]

DispatchFn = BuildAgentFn


def _config_path(root: Path) -> Path:
    return Path(root) / ".pravrudhi" / "heartbeat.yaml"


@dataclass(frozen=True)
class HeartbeatConfig:
    interval_min: int = 60
    max_dispatch_per_beat: int = 1
    quiet_hours: tuple[int, ...] = ()
    allow_gpu: bool = False


def load_config(root: Path) -> HeartbeatConfig:
    """The operator's heartbeat policy at `.pravrudhi/heartbeat.yaml`, or the packaged defaults if unset."""
    path = _config_path(root)
    raw: dict[str, Any] = yaml.safe_load(
        path.read_text(encoding="utf-8") if path.is_file() else PACKAGED_CONFIG.read_text(encoding="utf-8")
    ) or {}
    return HeartbeatConfig(
        interval_min=int(raw.get("interval_min", 60)),
        max_dispatch_per_beat=int(raw.get("max_dispatch_per_beat", 1)),
        quiet_hours=tuple(int(h) for h in (raw.get("quiet_hours") or ())),
        allow_gpu=bool(raw.get("allow_gpu", False)),
    )


#: What a beat names as its target: one dispatch's `{"request": ..., "criterion": ...}` (or the equivalent shape
#: for a non-obligations drive), or - since S6 - a list of such dicts when one beat dispatched more than one
#: independent criterion. A single-dispatch beat's `chose` is unchanged from before S6: a bare dict, never a
#: one-element list, so every existing reader keeps working without a change.
Chose = dict[str, str] | list[dict[str, str]] | None


@dataclass(frozen=True)
class BeatRecord:
    """What one call to `beat` did, or why it did nothing. Appended to `.pravrudhi/heartbeat.jsonl` unconditionally,
    a no-op beat included, so the log can be read as "is the heartbeat still ticking", not only "what did it do".

    `drive` and `drive_deficit` are the wire name (`kshudha.WIRE_NAMES`) and deficit of the drive `kshudha.select`
    chose, independent of what was actually dispatched — the two differ when `resources` wins but yields to the
    next eligible drive. `sentence` is `kshudha.sentence(appetite)`, the engine's own account of why."""

    at: str
    looked_at: tuple[str, ...]
    chose: Chose
    reason: str
    result: dict[str, Any] | None = None
    drive: str | None = None
    drive_deficit: float | None = None
    sentence: str = ""
    signals: tuple[str, ...] = ()
    """ADR-0056: non-blocking design-revisit signals from `maturity_signals.maturity_signals`, computed fresh
    every beat regardless of what the beat itself did. Empty for almost every beat on almost every root - it is
    populated only once this root's own real ledger/routing log has crossed one of the thresholds those
    functions detect. Never affects `chose`, `result`, or whether anything is dispatched or integrated."""

    def to_dict(self) -> dict[str, Any]:
        return {
            "at": self.at,
            "looked_at": list(self.looked_at),
            "chose": self.chose,
            "reason": self.reason,
            "result": self.result,
            "drive": self.drive,
            "drive_deficit": self.drive_deficit,
            "sentence": self.sentence,
            "signals": list(self.signals),
        }


def log_path(root: Path) -> Path:
    return Path(root) / ".pravrudhi" / "heartbeat.jsonl"


def _at(moment: datetime) -> str:
    aware = moment if moment.tzinfo else moment.replace(tzinfo=UTC)
    return aware.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def _append(root: Path, record: BeatRecord) -> None:
    path = log_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a") as fh:
        fh.write(json.dumps(record.to_dict(), sort_keys=True) + "\n")


def _finish(
    root: Path, moment: datetime, looked_at: tuple[str, ...], chose: Chose, reason: str,
    result: dict[str, Any] | None, *, drive: str | None, drive_deficit: float | None, sentence: str,
) -> BeatRecord:
    # ADR-0056: computed on every beat, whatever else it did - a non-blocking report, not a gate. Swallowed
    # rather than allowed to fail a beat: a signal that cannot be read is not worth losing the heartbeat over.
    signals: tuple[str, ...] = ()
    try:
        from pravrudhi.application.maturity_signals import maturity_signals as _maturity_signals
        signals = _maturity_signals(root)
    except Exception:
        signals = ()
    record = BeatRecord(
        at=_at(moment), looked_at=looked_at, chose=chose, reason=reason, result=result,
        drive=drive, drive_deficit=drive_deficit, sentence=sentence, signals=signals,
    )
    _append(root, record)
    return record


def history(root: Path, n: int = 20) -> list[BeatRecord]:
    """The last `n` beats, oldest first. A corrupt line is skipped, not fatal, like `subagents.runs`."""
    path = log_path(root)
    if not path.exists():
        return []
    out: list[BeatRecord] = []
    for line in path.read_text().splitlines():
        if not line.strip():
            continue
        try:
            d = json.loads(line)
            deficit = d.get("drive_deficit")
            out.append(
                BeatRecord(
                    at=str(d["at"]),
                    looked_at=tuple(d.get("looked_at") or ()),
                    chose=d.get("chose"),
                    reason=str(d.get("reason") or ""),
                    result=d.get("result"),
                    drive=d.get("drive"),
                    drive_deficit=float(deficit) if deficit is not None else None,
                    sentence=str(d.get("sentence") or ""),
                    signals=tuple(d.get("signals") or ()),
                )
            )
        except (json.JSONDecodeError, KeyError, TypeError):
            continue
    return out[-n:] if n > 0 else out


def _default_build_agent(root: Path) -> BuildAgentFn:
    def build(name: str, model: str | None) -> Any:
        return _registry_build_agent(root, name, model)

    return build


def _default_probe(root: Path) -> availability.ProbeFn:
    """The real check `beat` puts every cooling agent id in front of, built the way the CLI builds a route: an
    actual agent, asked the cheapest possible question (`availability.reprobe_prompt`), on the cheapest possible
    budget (`availability.reprobe_timeout_s`).

    Like `_default_judge`, independent of whatever `dispatch` a caller injected for the beat's own drive action —
    probing a cooling route is not the same call as dispatching real work to whichever route wins the beat, so
    it always builds its own agent rather than reusing that one. A route that cannot even be built, or that
    errors before answering, is not yet recovered: fail-closed, same direction as every other unclear answer in
    this module.
    """
    def probe(agent_id: str) -> bool:
        agent = _registry_build_agent(root, agent_id, None)
        if agent is None:
            return False
        workspace = None
        try:
            workspace = agent.create_workspace("reprobe")
            run = agent.run(availability.reprobe_prompt(), workspace, timeout_s=availability.reprobe_timeout_s())
            returncode = 0 if getattr(run, "ok", True) else 1
            return availability.classify(agent_id, str(run.text), returncode) != "limited"
        except (OSError, RuntimeError, ValueError):
            return False
        finally:
            if workspace is not None:
                with contextlib.suppress(OSError, RuntimeError):
                    agent.stop(workspace)

    return probe


ActionResult = tuple[Chose, str, dict[str, Any] | None]


def _beat_capability(
    root: Path, config: HeartbeatConfig, dispatch: DispatchFn | None,
) -> tuple[tuple[str, ...], Chose, str, dict[str, Any] | None]:
    """`samarthya` (capability): the original behaviour — the most-neglected undone step of any declared
    objective, dispatched through the swarm under the proposal sandbox policy."""
    objectives = load_all(root)
    looked_at = tuple(o.id for o in objectives)
    if not objectives:
        return looked_at, None, "no objectives declared in this workspace", None

    catalogue = tuple(recipes.library())
    installed = frozenset(recipes.installed())

    candidates: list[tuple[str, str, str, Any]] = []  # (last_dispatch_at, objective_id, step_id, task)
    steps_by_key: dict[tuple[str, str], Any] = {}
    for objective in objectives:
        plan = compile_intent(objective, catalogue, installed_skills=installed)
        tasks = subagents.tasks_from_plan(objective, plan, root=root)
        steps_by_id = {step.id: step for step in plan.steps}
        obj_runs = subagents.runs(root, objective.id)
        accepted_steps = {r.step for r in obj_runs if r.accepted}
        next_task = next(
            (t for t in tasks if t.spec.task_id.split(":", 1)[1] not in accepted_steps), None
        )
        if next_task is None:
            continue
        step_id = next_task.spec.task_id.split(":", 1)[1]
        steps_by_key[(objective.id, step_id)] = steps_by_id[step_id]
        last_at = max((r.at for r in obj_runs), default="")
        candidates.append((last_at, objective.id, step_id, next_task))

    if not candidates:
        return looked_at, None, "every objective's plan is fully dispatched and accepted", None

    candidates.sort(key=lambda c: (c[0], c[1]))
    _, objective_id, step_id, task = candidates[0]
    step = steps_by_key[(objective_id, step_id)]
    chose = {"objective": objective_id, "step": step_id}

    needs_gpu = step.capability in GPU_CAPABILITIES
    if needs_gpu and not config.allow_gpu:
        return looked_at, chose, f"step {step_id!r} needs the GPU and allow_gpu is false", None
    if needs_gpu and run_in_progress(root):
        return looked_at, chose, f"step {step_id!r} needs the GPU and a run is already in progress", None
    if config.max_dispatch_per_beat < 1:
        return looked_at, chose, "max_dispatch_per_beat is 0; nothing may be dispatched this beat", None

    build_agent = dispatch or _default_build_agent(root)
    scoped = replace(task, spec=apply_policy(task.spec, policy_for("proposal")))
    verdict = swarm.run_wave(build_agent, [scoped], log=lambda _msg: None, root=root)[0]
    run = subagents.SubagentRun(
        objective=objective_id, step=step_id, task_id=verdict.task_id, route=verdict.agent,
        accepted=verdict.accepted, wall_s=verdict.wall_s, files=tuple(verdict.files), reasons=tuple(verdict.reasons),
    )
    subagents.record_run(root, run)
    result = {"accepted": run.accepted, "route": run.route, "files": list(run.files), "reasons": list(run.reasons)}
    verb = "accepted" if run.accepted else "rejected"
    return looked_at, chose, f"dispatched {objective_id}:{step_id} ({verb})", result


def _obligation_scratch(request_id: str, index: int) -> str:
    return f"proposals/requests/{request_id}/{index}"


_ATTEMPTS_FILE = ".pravrudhi/criterion-attempts.json"

# Three paid attempts at one criterion is enough to learn that this loop cannot finish it unaided. The number is
# small on purpose: each attempt is a real dispatch to a real model, and the failure being guarded against is
# spending, not correctness.
MAX_CRITERION_ATTEMPTS = 3

# Paper stalls are free of model calls but each one reads and rewrites the requests store; a beat that meets
# a run of unbuildable criteria stalls this many before it yields, so one beat cannot spend its whole slot
# on bookkeeping if a triage batch drafted a hundred kernel criteria at once.
MAX_PAPER_STALLS_PER_BEAT = 25

# How much of a failed validator's output the beat keeps in its journal row: enough for pytest's summary and the
# last traceback, small enough that heartbeat.jsonl stays readable.
VALIDATION_OUTPUT_TAIL = 1500


def _attempts_path(root: Path) -> Path:
    return Path(root) / _ATTEMPTS_FILE


def _attempts_all(root: Path) -> dict[str, int]:
    try:
        data = json.loads(_attempts_path(root).read_text())
        return {str(k): int(v) for k, v in data.items()} if isinstance(data, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def _attempt_key(request_id: str, index: int) -> str:
    return f"{request_id}:{index}"


def attempts(root: Path, request_id: str, index: int) -> int:
    """How many times this exact criterion has been dispatched without moving."""
    return _attempts_all(root).get(_attempt_key(request_id, index), 0)


def record_attempt(root: Path, request_id: str, index: int) -> int:
    """Count one dispatch. On disk, because an hourly loop that forgot on restart would never reach any budget."""
    data = _attempts_all(root)
    key = _attempt_key(request_id, index)
    data[key] = data.get(key, 0) + 1
    path = _attempts_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=1, sort_keys=True))
    return data[key]


def clear_attempts(root: Path, request_id: str, index: int) -> None:
    """A criterion that moved has not stalled, whatever it cost to get there."""
    data = _attempts_all(root)
    if data.pop(_attempt_key(request_id, index), None) is None:
        return
    _attempts_path(root).write_text(json.dumps(data, indent=1, sort_keys=True))


def stalled(root: Path, request_id: str, index: int) -> bool:
    """Whether this criterion has spent its budget and should be left to the operator.

    Requests r-5795501a criterion 7 was dispatched nine times in one day, five of them accepted by the swarm and
    every one refused by the completion gate, while the criterion stayed unmet and the Lite Plan seat ran into
    its usage limit. Retrying is right; retrying the identical task hourly for ever is a standing order to spend.

    cli-web/cli-lead, 2026-09-14: `dispatch_failures_exhausted` existed and was already used to LABEL a beat's
    result "parked after N dispatch failures" (`_apply_verdict`), but `stalled` itself never consulted it - only
    judged attempts (which a dispatch failure never consumes) and the network-gap heuristic did. A criterion
    that only ever dispatch-fails, never reaching the judge (the product loop's `.pravrudhi-scratch` escape
    above was exactly this shape), was therefore never actually stalled: the label said "parked" and the
    selection logic kept re-selecting it anyway, hourly, regardless of the label.
    """
    if attempts(root, request_id, index) >= MAX_CRITERION_ATTEMPTS:
        return True
    if dispatch_failures_exhausted(root, request_id, index):
        return True
    return network_capability_gap(root, request_id, index)


# 2026-09-13, cli-lead: r-3981d7e0 criterion 3 (a real IL-TUR INSTALL.md needing live-fetched HuggingFace
# metadata) was re-dispatched 7 times over 2 requests before its budget ran out, and the judge was right every
# time -- the dispatch sandbox has no path to fetch that data, so no policy declares `network: open` for it, and
# no number of retries could ever produce the finished file. "Flag such criteria rather than letting the
# attempt budget drain" (cli-lead): once the judge's own reasoning names the same network-capability gap twice
# in a row, the criterion is parked early -- before spending the third attempt -- with a distinct reason rather
# than the generic "budget spent" a person would otherwise have to re-diagnose from scratch.
_NETWORK_GAP_RE = re.compile(
    r"\b(no network access|cannot fetch|no way to fetch|network access|live[- ]fetch(ed|ing)?|"
    r"sandbox has no (access|path)|fetched? from the (huggingface|hugging face|internet|web))\b",
    re.IGNORECASE,
)

#: Two independent judged-not-met verdicts naming the same capability gap is enough to believe it, one alone
#: could be an agent's own excuse rather than a real constraint.
_NETWORK_GAP_MIN_MATCHES = 2


def _all_judgements(root: Path, request_id: str, index: int) -> list[str]:
    """Every recorded judgement for this criterion, oldest first -- `_last_judgement` keeps only the newest,
    but detecting a repeated pattern needs the whole history."""
    request = requests.get(root, request_id)
    if request is None:
        return []
    prefix = _judgement_note(index, "")
    return [
        str(entry.get("note", ""))[len(prefix):].strip()
        for entry in request.notes
        if isinstance(entry, dict) and str(entry.get("note", "")).startswith(prefix)
    ]


def network_capability_gap(root: Path, request_id: str, index: int) -> bool:
    """Whether this criterion's own judgement history names a network-fetch capability no dispatch has, at
    least `_NETWORK_GAP_MIN_MATCHES` times -- see the module comment above `_NETWORK_GAP_RE`.

    cli-lead's layering decision (2026-09-13): `structural_incapability` (Studio's static Policy-vs-criterion
    check, cli-studio) is primary and fires inline at dispatch time on a knowable fact, declining the criterion
    directly before a judgement note is even written for that verdict (`_beat_obligations`'s own call site
    returns before reaching `requests.note`) -- so in the ordinary case this heuristic simply never sees a
    verdict her check already resolved. This call is the explicit, defence-in-depth half of "one incapability,
    one record": if her check would ALSO fire on this criterion's current mode/policy/text/last-rejection
    (possible if her check's own conditions became true only after some notes had already accumulated, e.g. a
    later attempt's rejection text is what first matches her `_PROPOSAL_NOT_EVIDENCE_RE`), this defers to her
    reason rather than adding a second, redundant one from judgement-text pattern-matching.
    """
    judgements = _all_judgements(root, request_id, index)
    request = requests.get(root, request_id)
    if request is not None and 0 <= index < len(request.criteria):
        criterion = request.criteria[index]
        mode = dispatch_mode(criterion, root=root)
        policy = _selfbuild_policy(root) if mode == "build" else policy_for("proposal")
        last_rejection = judgements[-1] if judgements else None
        if structural_incapability(
            mode=mode, policy=policy, criterion_text=criterion.text, rejection_text=last_rejection,
        ) is not None:
            return False
    matches = sum(1 for text in judgements if _NETWORK_GAP_RE.search(text))
    return matches >= _NETWORK_GAP_MIN_MATCHES


_GATE_ATTEMPTS_FILE = ".pravrudhi/gate-attempts.json"
_DISPATCH_FAILURES_FILE = ".pravrudhi/dispatch-failures.json"

# Like criterion attempts, gate attempts are budgeted. A gate that crashes should not rebuild a review agent
# every hour forever. Three attempts is the same budget as criteria.
MAX_GATE_ATTEMPTS = 3

# Dispatch-level failures (validation, workspace race, etc.) are separate from judged attempts. A criterion
# should be parked only after a configured number of dispatch failures, independent of judged attempt count.
MAX_DISPATCH_FAILURES = 3

_NOOP_STREAK_FILE = ".pravrudhi/noop-streak.json"

# ADR-0053 §5: a genuine "no change needed" report is a result, not a dispatch failure - it must not count
# towards MAX_DISPATCH_FAILURES at all. It is instead re-judged against the repository's current state, and the
# same budget of three (the number every other attempt cap in this file uses) closes the criterion as
# already-met once that many consecutive genuine no-ops have each been independently judged true.
MAX_NOOP_STREAK = 3


def _gate_attempts_path(root: Path) -> Path:
    return Path(root) / _GATE_ATTEMPTS_FILE


def _gate_attempts_all(root: Path) -> dict[str, int]:
    try:
        data = json.loads(_gate_attempts_path(root).read_text())
        return {str(k): int(v) for k, v in data.items()} if isinstance(data, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def gate_attempts(root: Path, request_id: str) -> int:
    """How many times the completion gate has been run on this request without succeeding."""
    return _gate_attempts_all(root).get(request_id, 0)


def record_gate_attempt(root: Path, request_id: str) -> int:
    """Count one gate execution. On disk, because an hourly loop that forgot on restart would never reach budget."""
    data = _gate_attempts_all(root)
    data[request_id] = data.get(request_id, 0) + 1
    path = _gate_attempts_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=1, sort_keys=True))
    return data[request_id]


def gate_stalled(root: Path, request_id: str) -> bool:
    """Whether this request's gate has spent its budget and should be left to the operator."""
    return gate_attempts(root, request_id) >= MAX_GATE_ATTEMPTS


def _dispatch_failures_path(root: Path) -> Path:
    return Path(root) / _DISPATCH_FAILURES_FILE


def _dispatch_failures_all(root: Path) -> dict[str, int]:
    try:
        data = json.loads(_dispatch_failures_path(root).read_text())
        return {str(k): int(v) for k, v in data.items()} if isinstance(data, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def dispatch_failures(root: Path, request_id: str, index: int) -> int:
    """How many times dispatch has failed (before judge ran) for this criterion."""
    key = f"{request_id}:{index}"
    return _dispatch_failures_all(root).get(key, 0)


def record_dispatch_failure(root: Path, request_id: str, index: int, *, now: datetime | None = None) -> int:
    """Count one dispatch-level failure (accepted=False). Separate from judged attempts.

    `now` is a test-only escape hatch for `DISPATCH_FAILURE_EXPIRY_HOURS`; production callers never pass it.
    """
    data = _dispatch_failures_all(root)
    key = f"{request_id}:{index}"
    data[key] = data.get(key, 0) + 1
    path = _dispatch_failures_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=1, sort_keys=True))
    _stamp_dispatch_failure(root, key, now=now)
    return data[key]


_DISPATCH_FAILURE_TIMES_FILE = ".pravrudhi/dispatch-failure-times.json"

# The fallback for a wall `external_wall_reason` does not recognise (2026-09-13, cli-lead): Studio's
# r-cad91781:13 and product's r-55c7083e:1 were both parked on the exact same vendor session-limit message,
# and stayed parked with no way back until a lead hand-edited the JSON, because nothing reversed
# `record_dispatch_failure`. The primary fix is that this text is now recognised and never recorded at all
# (see `external_wall_reason`); this is the safety net for a phrasing that is not, so an unnamed external cause
# still cannot wedge a criterion shut forever. Six hours is long enough that a session-limit or memory-floor
# wall (both measured in minutes to a few hours) has certainly passed, short enough that a criterion genuinely
# re-failing keeps counting well within the same working day.
DISPATCH_FAILURE_EXPIRY_HOURS = 6.0

_TIME_STAMP = "%Y-%m-%dT%H:%M:%SZ"


def _dispatch_failure_times_path(root: Path) -> Path:
    return Path(root) / _DISPATCH_FAILURE_TIMES_FILE


def _dispatch_failure_times_all(root: Path) -> dict[str, str]:
    try:
        data = json.loads(_dispatch_failure_times_path(root).read_text())
        return {str(k): str(v) for k, v in data.items()} if isinstance(data, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def _stamp_dispatch_failure(root: Path, key: str, *, now: datetime | None = None) -> None:
    data = _dispatch_failure_times_all(root)
    data[key] = (now or datetime.now(UTC)).strftime(_TIME_STAMP)
    path = _dispatch_failure_times_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=1, sort_keys=True))


def _unstamp_dispatch_failure(root: Path, key: str) -> None:
    data = _dispatch_failure_times_all(root)
    if data.pop(key, None) is None:
        return
    _dispatch_failure_times_path(root).write_text(json.dumps(data, indent=1, sort_keys=True))


# The host's own memory-floor refusal (heartbeat.py's own `_narrow_for_memory` message uses "below the ... GB
# floor") is inherently a refusal and cannot occur as incidental prose in an agent's own output - unlike the
# phrases below, it needs no corroborating context.
_UNAMBIGUOUS_WALL_RE = re.compile(
    r"\b(quota exhausted|out of memory|\boom\b|insufficient memory|below the [\d.]+\s*gb floor)\b",
    re.IGNORECASE,
)

# A vendor's account-quota or session-limit message looks like this, but so does an agent's own prose about a
# task that happens to be *about* rate limiting ("The script should rate limit its requests to the API") - a
# dispatch failure carries the agent's output, not just the vendor's, and cli-lead caught that exact false
# positive on 2026-09-13 before it shipped: it would have let a genuinely failing criterion burn its dispatch
# budget forever, the opposite failure from the one this module exists to fix. So these phrases alone are not
# enough; `external_wall_reason` also requires `_WALL_CONTEXT_RE` to appear in the same reason.
_LIMIT_PHRASE_RE = re.compile(r"\b(usage limit|session limit|rate limit(?:ed)?)\b", re.IGNORECASE)

# What a vendor's own refusal reads like around one of the phrases above ("You've hit your session limit ·
# resets 11:40am (Europe/London)" is the literal incident text) - a task's prose about rate limiting has no
# reason to say any of these.
_WALL_CONTEXT_RE = re.compile(
    r"\b(you'?ve hit|hit (?:its|your|a|the) |exceeded|resets?\b|try again|\b429\b)", re.IGNORECASE,
)


def external_wall_reason(reasons: list[str]) -> str | None:
    """The external-wall phrase these dispatch-failure reasons name (a vendor's usage/session limit, or a
    memory-floor refusal), or `None`. A dispatch that failed for one of these reasons says nothing about
    whether the criterion is buildable, the same distinction ADR-0053 §5 draws for a genuine no-op - it must
    never count towards `MAX_DISPATCH_FAILURES`. Anchored on phrases the actual incidents used rather than a
    precise vendor format, the same loose-substring trade-off `availability.classify` makes: a wrong call only
    mis-counts one dispatch failure, it never crashes a beat."""
    for reason in reasons:
        match = _UNAMBIGUOUS_WALL_RE.search(reason)
        if match:
            return match.group(1).lower()
    for reason in reasons:
        match = _LIMIT_PHRASE_RE.search(reason)
        if match and _WALL_CONTEXT_RE.search(reason):
            return match.group(1).lower()
    return None


def clear_dispatch_failures(root: Path, request_id: str, index: int) -> None:
    """Manually forget a criterion's dispatch-failure count and its timestamp - the `clear_attempts` of dispatch
    failures, for the case an external wall's phrasing was not one `external_wall_reason` recognises."""
    data = _dispatch_failures_all(root)
    key = f"{request_id}:{index}"
    if data.pop(key, None) is not None:
        _dispatch_failures_path(root).write_text(json.dumps(data, indent=1, sort_keys=True))
    _unstamp_dispatch_failure(root, key)


def dispatch_failures_exhausted(root: Path, request_id: str, index: int, *, now: datetime | None = None) -> bool:
    """Whether this criterion has spent its dispatch failure budget.

    A budget that was spent `DISPATCH_FAILURE_EXPIRY_HOURS` or more ago is presumed spent against a wall that
    has since passed (see `DISPATCH_FAILURE_EXPIRY_HOURS`), not against this criterion, so it no longer parks
    the criterion; the raw count from `dispatch_failures` is left alone as a historical fact."""
    if dispatch_failures(root, request_id, index) < MAX_DISPATCH_FAILURES:
        return False
    key = f"{request_id}:{index}"
    stamped = _dispatch_failure_times_all(root).get(key)
    if stamped is None:
        return True  # no timestamp recorded (predates this feature, or a manual edit): behave as before
    try:
        last = datetime.strptime(stamped, _TIME_STAMP).replace(tzinfo=UTC)
    except ValueError:
        return True
    moment = now if (now is not None and now.tzinfo) else (now.replace(tzinfo=UTC) if now else datetime.now(UTC))
    return moment - last < timedelta(hours=DISPATCH_FAILURE_EXPIRY_HOURS)


def _noop_streak_path(root: Path) -> Path:
    return Path(root) / _NOOP_STREAK_FILE


def _noop_streak_all(root: Path) -> dict[str, int]:
    try:
        data = json.loads(_noop_streak_path(root).read_text())
        return {str(k): int(v) for k, v in data.items()} if isinstance(data, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def noop_streak(root: Path, request_id: str, index: int) -> int:
    """How many consecutive genuine no-op dispatches this criterion has had, each independently judged met."""
    key = f"{request_id}:{index}"
    return _noop_streak_all(root).get(key, 0)


def record_noop(root: Path, request_id: str, index: int) -> int:
    """Count one genuine no-op judged met. ADR-0053 §5 - never a dispatch failure."""
    data = _noop_streak_all(root)
    key = f"{request_id}:{index}"
    data[key] = data.get(key, 0) + 1
    path = _noop_streak_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=1, sort_keys=True))
    return data[key]


def clear_noop_streak(root: Path, request_id: str, index: int) -> None:
    """A judged-false no-op, or the criterion closing, breaks the streak - the next no-op starts counting from 1."""
    data = _noop_streak_all(root)
    key = f"{request_id}:{index}"
    if key in data:
        del data[key]
        _noop_streak_path(root).write_text(json.dumps(data, indent=1, sort_keys=True))


def _is_genuine_noop(verdict: Any) -> bool:
    """ADR-0053 §5: `delegate.dispatch`'s `diff.empty` branch already separates a genuine no-op (the agent's own
    explanation, and nothing else wrong) from a real escape (which adds a second reason, e.g. `wrote outside its
    worktree`). Exactly one reason, and it is that explanation, is what makes routing to the judge instead of
    the dispatch-failure counter safe."""
    return len(verdict.reasons) == 1 and verdict.reasons[0].startswith("no change produced: ")


def _obligation_prompt(
    request_text: str, criterion_text: str, scratch: str, validate: str, *, prior: str = "",
    toolchain: str | None = None,
) -> str:
    """`prior` is why the last attempt at this criterion was judged short.

    Three dispatches at the same criterion each started from nothing and produced twenty-odd files apiece,
    because none of them was told what the previous one had failed to do. A retry that carries the reason is a
    second attempt; one that does not is the first attempt again at full price.

    `toolchain`: 2026-09-13, r-5795501a criterion 8 - every attempt was written in Python against
    `p._electron`, which does not exist there. Rendered as its own explicit line rather than folded into the
    criterion's own prose, so an agent cannot miss it the way three of them missed it when it was absent.
    """
    fell_short = f"A previous attempt was judged NOT to meet this criterion because: {prior}\n\n" if prior else ""
    required = f"Required toolchain: {toolchain}\n\n" if toolchain else ""
    return (
        f"Operator request (verbatim): {request_text}\n\n"
        f"Oldest unmet acceptance criterion: {criterion_text}\n\n"
        f"{required}"
        f"{fell_short}"
        "Everything you write is a PROPOSAL toward this criterion, not evidence: nothing you produce may write to "
        "the ledger, research/, gates/ or pravrudhi_kernel/, and no number you state may be presented as a result. "
        "This bars more than a bare claim of a result: do not write ANY number, percentage or score that reads as "
        "an outcome, even one you call fabricated, simulated, hypothetical, illustrative, a placeholder, or made "
        "only to exercise a script - CHARTER §6 is no number is stated that the ledger does not contain, and "
        "saying so in the same sentence does not except you from it. If a script needs a value to run, use an "
        "unmistakably non-numeric stand-in (e.g. `PLACEHOLDER`), never a plausible-looking number.\n"
        f"Deliverable, written only under {scratch}/ using RELATIVE paths: a README.md stating the approach and "
        "what would count as evidence this criterion is met; plus any scripts. Scripts must at least compile.\n"
        f"Validate with `{validate}`."
    )


_JUDGE_MARKER = "verdict:"


def _judge_prompt(
    request_text: str, criterion_text: str, files: list[str], *, where: str = "the repository root"
) -> str:
    listing = "\n".join(f"  - {f}" for f in files) or "  (nothing)"
    return (
        "You are judging one acceptance criterion. You do not write code and you fix nothing.\n\n"
        f"Operator request (verbatim): {request_text}\n\n"
        f"The criterion: {criterion_text}\n\n"
        f"What the last dispatch produced, relative to {where}:\n{listing}\n\n"
        "Read those files. That listing is what the dispatch CHANGED, not the limit of what you may look at: "
        "your working directory holds the whole tree, and a criterion about whether something is still "
        "referenced, reachable, removed everywhere, or consistent with the rest of the repository can only be "
        "answered by reading beyond the listing. Do that before concluding a repository-wide claim, and say "
        "what you checked.\n"
        "Decide whether they actually satisfy the criterion as written - not whether they are "
        "good work, and not whether they describe satisfying it. A proposal that explains what would meet the "
        "criterion does not meet it.\n"
        "Also refuse (not met) if any file states a number, percentage, score or outcome AS an obtained result "
        "when no real run produced it - including one the file itself admits is fabricated, simulated, "
        "hypothetical, a placeholder, or made only to exercise a script. CHARTER §6: no number is stated that "
        "the ledger does not contain. A file that is honest about inventing a number has still not met a "
        "criterion that number was meant to satisfy.\n"
        "Answer with a first line of exactly `VERDICT: met` or `VERDICT: not met`, then one short paragraph "
        "saying why. If you say not met, say what is missing, because the next attempt is given your reason."
    )


# How much of the judge's reason is kept for the next attempt to start from. 300 characters cut r-1977143a's two
# refusals off before the sentence that said what was missing (2026-09-11), so the retry began from a hint that
# named the strengths and none of the gap.
_JUDGEMENT_CHARS = 1500


def _judged(text: str) -> tuple[bool, str]:
    """Whether the judge said met, fail-closed.

    Anything that is not an explicit `VERDICT: met` is not met - the discipline `completion._judge_review`
    applies to a confident summary that does not show its work, for the same reason: this decision closes a
    criterion, and a judge that cannot be bothered to say so plainly has not made it.
    """
    lines = [line.strip() for line in (text or "").splitlines() if line.strip()]
    for i, line in enumerate(lines):
        # Models bold or quote the marker (`**VERDICT: met**` cost r-35e8ce7b criterion 7 a met verdict on
        # 2026-09-11): emphasis is not a different answer, so it is stripped before the marker is read.
        low = line.lower().strip("*_`# ").replace("**", "").replace("`", "")
        if low.startswith(_JUDGE_MARKER):
            said = low.split(":", 1)[1].strip(" *_`")
            reason = " ".join(lines[i + 1:])[:_JUDGEMENT_CHARS] or line
            return said.startswith("met"), reason
    return False, (" ".join(lines)[:_JUDGEMENT_CHARS] or "the judge said nothing")


@dataclass(frozen=True)
class StructuralIncapability:
    """A fact about the dispatch mode or policy, knowable independent of repeated observation, that makes a
    criterion's acceptance bar unreachable by any dispatch in that mode - the loop's own doing, not the agent's.
    cli-lead, 2026-09-13: 'a fact about the dispatch mode or policy, knowable before the first attempt, that
    makes the criterion's acceptance bar unreachable.' Distinct from trackB's judgement-text fallback
    (`heartbeat.network_capability_gap`), which exists for the incapability neither category here can see in
    advance - a nominally-capable dispatch failing for a real-world reason no policy field encodes."""

    category: str
    reason: str


# A live external lookup the criterion names, matched against a policy whose network is "none": a clean
# two-sided comparison (a policy field on one side, a criterion demanding a fetch on the other) that needs no
# rejection to learn, since it is true before any dispatch happens at all.
_LIVE_FETCH_RE = re.compile(
    r"\b(fetch|download|retrieve|look ?up)\b.{0,40}\b(live|current|actual|real[- ]time|online)\b"
    r"|hugging ?face|its own (?:web )?page|the (?:dataset|package)'s (?:actual )?(?:size|licen[cs]e)",
    re.IGNORECASE,
)

# The judge's own fixed template sentence (_judge_prompt, below): "A proposal that explains what would meet the
# criterion does not meet it." A rejection built from that frame reliably echoes its own vocabulary - this is
# anchored to language the prompt itself trains into the judge, not arbitrary free prose trackB's fallback has
# to key on instead.
_PROPOSAL_NOT_EVIDENCE_RE = re.compile(
    r"(explains?|describes?) what would (meet|satisfy)"
    r"|not (the )?evidence"
    r"|a proposal\b.{0,60}\bnot (the )?evidence",
    re.IGNORECASE,
)

# When the criterion's OWN text already states its bar is evidence that executing something produced (a real
# run, a recording, a demonstrated execution), that bar is knowable before any dispatch, same as the network
# case - no rejection needed to learn it. Anchored to an explicit "actual"/"real" qualifier deliberately: a bare
# "records it" or "drives ... through an update" (r-5795501a c8's own words) does not by itself rule out a
# capable, not-yet-executed script satisfying the bar - that ambiguity is real, not a regex gap, which is why
# this criterion needs its first rejection to learn the bar rather than being caught here.
_EXECUTED_EVIDENCE_BAR_RE = re.compile(
    r"\b(?:a |the )?recording of an? (?:actual|real) (?:run|execution)\b"
    r"|\bactual(?:ly)? run\b"
    r"|\breal[- ]time run\b"
    r"|\bdemonstrat(?:e|ed|ing)\b.{0,20}\bexecut",
    re.IGNORECASE,
)

# 2026-09-13, cli-lead (after re-reading r-5795501a criterion 8's full judgement history, not just its latest
# verdict): the criterion demands a real Electron-shell run, and every rejection after the first correct code
# review (a `p._electron` bug, fixed) says the same underlying thing in different words - the dispatch sandbox
# has no display, browser or Electron runtime to actually run anything against, so no script, however correct,
# can ever produce the run it is judged on. `_PROPOSAL_NOT_EVIDENCE_RE` does not match this wording (it wants
# "explain[s]"/"describe[s]" or the literal phrase "not evidence"; the real verdict here says "explaining"
# and "lacks the actual evidence" instead), which is exactly how this criterion kept re-consuming beats after
# cli-lead read only the earlier, narrower rejection and believed the gap was already closed.
_NO_EXECUTION_ENV_RE = re.compile(
    r"\b(?:playwright|electron|xvfb|(?:a |the )?(?:real |working )?display|(?:a |the )?gui|(?:a |the )?browser)\b"
    r".{0,40}\b(?:not available|unavailable|is not installed|not installed|not present)\b"
    r"|\bno real (?:engine|display|browser) is running\b"
    r"|\b(?:cannot|can'?t) (?:launch|open|run) (?:a |the )?(?:browser|display|electron)\b"
    r"|\bsandbox has no\b.{0,40}\b(?:display|gui|graphical|browser)\b",
    re.IGNORECASE,
)


def structural_incapability(
    *, mode: str, policy: Policy, criterion_text: str, rejection_text: str | None,
) -> StructuralIncapability | None:
    """Whether this criterion's bar is unreachable by any dispatch in `mode`, checked in a fixed order (the
    first category that applies wins).

    The categories are not equally static. `network` is a clean two-sided comparison and can fire without ever
    seeing a rejection - the criterion names a live lookup, the policy's network is 'none', done.
    `no_evidence_in_proposal_mode` is asymmetric: `mode == "proposal"` alone proves nothing, since proposal is
    the ordinary mode for most criteria and firing on it alone would park most of the backlog. The
    discriminating fact is the CRITERION'S BAR, not the mode - where the criterion's own text already states
    that bar (an executed, recorded run), this fires before any dispatch, same as `network`; where it does not,
    the first rejection is what reveals it. `no_execution_environment` is learned the same way, from a
    rejection, but is not mode-scoped - a missing display, browser or runtime is a fact about the route, not
    about proposal-vs-build, so it applies wherever it is said.
    """
    if policy.network == "none" and _LIVE_FETCH_RE.search(criterion_text):
        return StructuralIncapability(
            "network",
            "the criterion names a live external lookup, and the assigned policy's network is 'none' - no "
            "dispatch in this mode can ever fetch it",
        )
    if rejection_text and _NO_EXECUTION_ENV_RE.search(rejection_text):
        return StructuralIncapability(
            "no_execution_environment",
            "the judge's rejection said the dispatch sandbox lacks a display, browser or runtime (Electron, "
            "Playwright, Xvfb) the criterion needs to produce a real run - no dispatch on this route can ever "
            "produce that evidence until a route with that capability exists",
        )
    if mode == "proposal":
        if _EXECUTED_EVIDENCE_BAR_RE.search(criterion_text):
            return StructuralIncapability(
                "no_evidence_in_proposal_mode",
                "the criterion's own text demands evidence that executing something produced, and proposal "
                "mode's brief states outright that nothing it writes counts as evidence",
            )
        if rejection_text and _PROPOSAL_NOT_EVIDENCE_RE.search(rejection_text):
            return StructuralIncapability(
                "no_evidence_in_proposal_mode",
                "the judge's rejection said this was a proposal describing what would satisfy the criterion "
                "rather than being the evidence itself - proposal mode can never be anything else",
            )
    return None


# r-3981d7e0 criterion 5 was judged met with a README that stated, in its own words, that its numbers were
# "fabricated to exercise the scripts" - honest about breaking CHARTER §6, and accepted anyway, because nothing
# told the judge that a self-declared fabrication is still a fabrication. Asking the judge more clearly (see
# `_judge_prompt`) is one layer; a judge is an LLM reading prose and can be talked past the same way this one
# already was, so this is a second, deterministic layer that does not depend on the judge noticing at all.
_FABRICATION_MARKERS: tuple[str, ...] = (
    "fabricat",  # fabricated / fabricating / a fabrication
    "simulat",  # simulated / simulating a result
    "hypothetical",
    "made up",
    "made-up",
    "placeholder value",
    "placeholder number",
    "dummy data",
    "dummy value",
    "for illustration",
    "illustrative purposes",
    "to exercise the script",
    "not actually measured",
    "not a real measurement",
    "invented for",
)


def _self_declared_fabrication(text: str) -> str | None:
    """The marker phrase, if this text admits that a number in it is not a real measurement."""
    low = text.lower()
    for marker in _FABRICATION_MARKERS:
        if marker in low:
            return marker
    return None


def _first_unevidenced_claim(workspace: Path, files: list[str]) -> str | None:
    """The first marker phrase found across the produced files, read from where they were actually written.

    A file that cannot be read (wrong workspace, already cleaned up, a test double that never wrote real files)
    is silently skipped rather than treated as a violation: this backstop only ever adds a refusal, it never
    manufactures one from an absence it cannot account for.
    """
    for name in files:
        try:
            text = (workspace / name).read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        marker = _self_declared_fabrication(text)
        if marker is not None:
            return marker
    return None


def _default_judge(root: Path, *, workspace: Path | None = None) -> Any:
    """The read-only agent that judges a criterion, on the cheap seat.

    Judging is reading and answering, which is what `subagents` calls mechanical work; paying design rates to
    ask "does this file do what the criterion says" is how a plan's allowance disappears into bookkeeping.

    `workspace` is the tree the judge reads in. A build criterion's change exists only in the dispatch's own
    worktree until integration, so its judge must run there: until 2026-09-11 the judge read a fresh worktree of
    HEAD, found none of the functions the criterion named, and refused four build attempts in a row for work
    that was sitting one directory over. A workspace handed in is borrowed, never removed.
    """
    def ask(*, prompt: str) -> str:
        agent = _registry_build_agent(root, "claude-code", "haiku")
        if agent is None:
            return ""
        own = None
        try:
            own = None if workspace is not None else agent.create_workspace("judge")
            return str(agent.run(prompt, workspace if workspace is not None else own, timeout_s=600).text)
        except (OSError, RuntimeError, ValueError):
            # A machine with no usable agent, or a root that is not a checkout, must not take the beat down: an
            # unjudgeable criterion is simply not met, which is the fail-closed direction and the same one
            # `completion._default_review_agent` takes when it cannot review.
            return ""
        finally:
            if own is not None:
                with contextlib.suppress(OSError, RuntimeError):
                    agent.stop(own)

    return ask


def _last_judgement(root: Path, request_id: str, index: int) -> str:
    """The reason the previous attempt at this criterion was refused, for the next attempt to start from."""
    request = requests.get(root, request_id)
    prefix = _judgement_note(index, "")
    for entry in reversed(request.notes if request else []):
        note = str(entry.get("note", "")) if isinstance(entry, dict) else str(entry)
        if note.startswith(prefix):
            return note[len(prefix):].strip()
    return ""


def _judgement_note(index: int, why: str) -> str:
    return f"criterion {index} not yet met: {why}"


def _current_head(root: Path) -> str:
    """The commit an already-met verdict's evidence points at (ADR-0053 §5): a criterion closed on the strength
    of existing repository state should name which state, so the claim stays checkable after the fact."""
    try:
        p = subprocess.run(["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True, timeout=30)
        return p.stdout.strip() if p.returncode == 0 and p.stdout.strip() else "unknown"
    except (OSError, subprocess.SubprocessError):
        return "unknown"


_LOOP_SYNC_TIMEOUT_S = 120


def _sync_loop_branch(root: Path) -> str | None:
    """ADR-0053 §3: before any dispatch, bring a loop root's branch up to date with `origin/main` by rebase, so
    a hypothesis is tested against what the team has actually landed rather than an increasingly stale clone.

    Only acts when `root` is a git work tree currently on a `loop/*` branch (§1: that is the only kind of root
    this ADR moves deliberately). Every other root - not a git repository at all, or a git repository on `main`
    or anything else - is left strictly untouched. This is not an incidental narrowing: `beat()` calls this
    unconditionally on every root, including the lead's own main checkout, which stays on plain `main` until an
    explicit re-root. Guarding on "is this a git repo" alone would rebase that checkout every hour - the tree the
    lead cherry-picks assistant branches into and the publisher commits `demo.json` into, rewriting shas not yet
    pushed and aborting a rebase in a tree someone else is actively working in. The branch check is what keeps
    this a no-op everywhere until a root is deliberately re-rooted onto `loop/<name>`, rather than by accident.

    Returns None on success (including "nothing to sync", "not a loop root", and "not a git repository at all")
    or the conflict detail if the rebase could not complete. The loop never resolves a conflict itself: on
    failure the rebase is aborted, leaving the tree exactly as it was, and the detail is reported so a person
    looks at it.

    A fetch failure (network hiccup, no remote configured) is treated the same as nothing-to-sync rather than a
    conflict - that distinction matters only for a genuine content conflict a person must resolve; nothing to
    resolve here, the next beat tries again.

    2026-09-14: a loop root with any local commit ahead of `origin/main` (one the loop's own `_push_loop_branch`
    never reached, or one recovered by hand from a stuck dispatch) needs `git rebase` to recreate that commit's
    object every single time this runs, which needs a committer identity - and a bare clone with no local
    `user.name`/`user.email` and no `~/.gitconfig` has none. Studio's own `loop/studio` checkout hit exactly
    this for over an hour, every beat, on one such commit: "Committer identity unknown", the rebase aborted,
    and the loop silently stopped picking up anything from `main` at all while its label kept saying only
    "rebase-conflict". `COMMIT_IDENTITY` (already used by `integrate.py` for the loop's OWN build-mode commits)
    is passed the same way here, so this never depends on ambient git config existing in the checkout.
    """
    def run(*args: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            ["git", *args], cwd=root, capture_output=True, text=True, timeout=_LOOP_SYNC_TIMEOUT_S,
            env={**os.environ, **COMMIT_IDENTITY},
        )

    try:
        probe = run("rev-parse", "--is-inside-work-tree")
    except (OSError, subprocess.SubprocessError):
        return None
    if probe.returncode != 0 or probe.stdout.strip() != "true":
        return None
    try:
        branch = run("rev-parse", "--abbrev-ref", "HEAD")
    except (OSError, subprocess.SubprocessError):
        return None
    if branch.returncode != 0 or not branch.stdout.strip().startswith("loop/"):
        return None
    if run("fetch", "origin", "main").returncode != 0:
        return None
    _reset_regenerable_lockfiles(run)
    rebased = run("rebase", "origin/main")
    if rebased.returncode == 0:
        return None
    detail = (rebased.stderr or rebased.stdout).strip()[:500]
    run("rebase", "--abort")
    if _is_dirty_tree_precheck_failure(detail):
        detail = f"dirty-tree({_dirty_tree_scope_tag(root)}): {detail}"
    return detail


# 2026-09-14: `pyproject.toml`'s version can be bumped at release without regenerating `uv.lock` in the same
# commit (v0.5.20 shipped this way). Every `uv sync`/`uv run` a loop root does after that then re-derives the
# newer version into `uv.lock` locally, dirtying a tracked file the precheck above treats exactly like a real
# uncommitted change - and unlike genuine work, nothing the loop does ever commits that drift, so it parks the
# beat forever rather than for one cycle. `loop/studio` sat on this for three consecutive beats (all also
# masked behind an unrelated `external_wall: session limit` that resolved on its own reset) before it was
# unblocked by hand. Nobody hand-authors these files and the tool reproduces the same content from source on
# every invocation, so resetting one to its committed state here discards nothing a person wrote - if
# `origin/main`'s own copy has changed, the reset version is what the rebase should replay onto anyway.
_REGENERABLE_LOCKFILES = ("uv.lock",)


def _reset_regenerable_lockfiles(run: Callable[..., subprocess.CompletedProcess[str]]) -> None:
    """Reset any dirty entry in `_REGENERABLE_LOCKFILES` to its committed state, so lockfile churn never blocks
    the rebase precheck. Never touches anything else - a genuine conflict elsewhere in the tree still reports
    exactly as before `_sync_loop_branch` calls this."""
    for name in _REGENERABLE_LOCKFILES:
        try:
            clean = run("diff", "--quiet", "HEAD", "--", name)
        except (OSError, subprocess.SubprocessError):
            continue
        if clean.returncode == 0:
            continue  # not dirty (or not tracked) - nothing to reset
        run("checkout", "HEAD", "--", name)


def _push_loop_branch(root: Path) -> str | None:
    """pravrudhi-app ADR-0002: publish a loop root's branch to `origin` right after a successful build-mode
    integration, so a criterion the loop closes is visible to anyone outside the machine it ran on. Before
    this, `_sync_loop_branch` above pulled `origin/main` into a `loop/*` root every beat, but nothing pushed
    in the other direction -- a loop could close criteria indefinitely while `git ls-remote --heads origin
    loop/product` stayed empty, which is exactly what happened: the product loop's one met criterion sat
    unreachable from any remote ref, so none of it ever reached `origin/main`, a Vercel deploy, or a release
    tag (all cut from `main`, which this never touches -- the push is to the branch's own name).

    Same guard as `_sync_loop_branch`: only acts on a git work tree currently on a `loop/*` branch. Returns
    None on success (including "not a loop root" and "not a git repository") or the push failure detail
    otherwise. A push failure must never break the beat or undo the integration that already happened -- the
    next beat's rebase-then-push tries again, the same swallow-and-continue discipline `_sync_loop_branch`
    and `notifications.emit` already use elsewhere in this file. Promotion of this branch into `main` stays a
    separate act through the existing `/inbox/sign` path (ADR-0040); this never pushes to `main` itself.
    """
    def run(*args: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            ["git", *args], cwd=root, capture_output=True, text=True, timeout=_LOOP_SYNC_TIMEOUT_S,
        )

    try:
        probe = run("rev-parse", "--is-inside-work-tree")
    except (OSError, subprocess.SubprocessError):
        return None
    if probe.returncode != 0 or probe.stdout.strip() != "true":
        return None
    try:
        branch = run("rev-parse", "--abbrev-ref", "HEAD")
    except (OSError, subprocess.SubprocessError):
        return None
    name = branch.stdout.strip()
    if branch.returncode != 0 or not name.startswith("loop/"):
        return None
    try:
        pushed = run("push", "origin", f"HEAD:{name}")
    except (OSError, subprocess.SubprocessError) as exc:
        return str(exc)[:500]
    if pushed.returncode == 0:
        return None
    return (pushed.stderr or pushed.stdout).strip()[:500]
# git refuses to even attempt a rebase, before any content is compared, when the working tree carries
# uncommitted changes -- "error: cannot rebase: You have unstaged changes." or "...Your index contains
# uncommitted changes.", both followed by "Please commit or stash them." This is a materially different
# problem from a genuine content conflict during rebase (which instead names the commit and the file, e.g.
# "could not apply <sha>... <subject>"): nothing has been compared yet, there is nothing to resolve by hand
# the way a merge conflict is, and repeating the identical generic message every beat for hours (2026-09-13,
# the product loop, 8 consecutive beats over 7+ hours) is a different failure than the one this function
# already reports well.
_DIRTY_TREE_PRECHECK_RE = re.compile(
    r"cannot rebase:.*(unstaged changes|uncommitted changes).*please commit or stash",
    re.IGNORECASE | re.DOTALL,
)


def _is_dirty_tree_precheck_failure(detail: str) -> bool:
    return bool(_DIRTY_TREE_PRECHECK_RE.search(detail))


def _dirty_tree_scope_tag(root: Path) -> str:
    """Whether every dirty path is somewhere this loop's own declared build scope says it may write, or whether
    at least one path is content the loop does not recognise as its own.

    Read-only (`git status --porcelain`) -- this never stages, commits or discards anything. The distinction
    matters because an auto-recovery that discards or commits blind is the danger cli-lead named (2026-09-13):
    a dirty tree entirely inside `resolved_allowed_prefixes` is plausibly this loop's own build output that
    failed to commit; anything outside it (as the product loop's stray `harness/`/`research/` from a prior
    mis-rooted period were, both outside `frontend/`, `desktop/`, `engine/`, `scripts/`, `docs/`) must not be
    assumed safe, and is reported as unrecognised rather than silently treated as ours.
    """
    from pravrudhi.application import build_config

    try:
        status = subprocess.run(
            ["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True, timeout=30,
        )
    except (OSError, subprocess.SubprocessError):
        return "unrecognized"
    if status.returncode != 0:
        return "unrecognized"
    paths = [line[3:].strip() for line in status.stdout.splitlines() if line.strip()]
    if not paths:
        return "unrecognized"
    prefixes = build_config.resolved_allowed_prefixes(root)
    if all(any(p.startswith(prefix) for prefix in prefixes) for p in paths):
        return "own-scope"
    return "unrecognized"


_REBASE_CONFLICT_STREAK_FILE = ".pravrudhi/rebase-conflicts.json"

# ADR-0053 §3 amendment: quiet hours resolve themselves; a rebase conflict does not. Once the streak reaches
# this many consecutive beats, the loop alerts externally rather than staying quiet - a heartbeat alive while
# convergence is zero, with nobody told, is the failure the operator named. Same budget as every other strike
# count in this file.
MAX_REBASE_CONFLICTS_BEFORE_ALERT = 3


def _rebase_conflict_streak_path(root: Path) -> Path:
    return Path(root) / _REBASE_CONFLICT_STREAK_FILE


def rebase_conflict_streak(root: Path) -> int:
    """How many consecutive beats this loop root has failed to sync with origin/main."""
    try:
        data = json.loads(_rebase_conflict_streak_path(root).read_text())
        return int(data.get("streak", 0)) if isinstance(data, dict) else 0
    except (OSError, ValueError, TypeError):
        return 0


def record_rebase_conflict(root: Path) -> int:
    """Count one beat that could not sync with origin/main."""
    streak = rebase_conflict_streak(root) + 1
    path = _rebase_conflict_streak_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"streak": streak}))
    return streak


def clear_rebase_conflict_streak(root: Path) -> None:
    """A successful sync breaks the streak - the next conflict, if any, starts counting from 1."""
    path = _rebase_conflict_streak_path(root)
    if path.exists():
        path.unlink()


def _alert_rebase_conflict_streak(root: Path, streak: int, detail: str) -> None:
    """Reaches the operator the same way a night finishing or a critical audit finding does (`reach.send`'s
    `rebase_conflict_streak` kind), rather than depending on anyone reading `.pravrudhi/heartbeat.jsonl`. A
    delivery failure must never take the beat down with it, so this mirrors `notifications._reach`'s own
    swallow-and-continue discipline."""
    try:
        from pravrudhi.application import notifications

        notifications.emit(
            root, kind="rebase_conflict_streak",
            title=f"loop stalled: {streak} consecutive rebase conflicts",
            detail=detail, engine_root=root,
        )
    except Exception:  # noqa: BLE001 (a notification that cannot be delivered must never take the beat with it)
        return


# A criterion is proposal-shaped work like an evaluate/corpus step (subagents._TIER_BY_CAPABILITY), not a
# candidate-shaping one — a fixed policy choice, not a measurement.
_OBLIGATION_TIER = "standard"


_REVIEW_CRITERION_PREFIX = "Answer the completion review's finding: "


_NAMES_SOMETHING = re.compile(r"`[^`]+`|\b[\w-]+\.(?:py|tsx|ts|jsx|js|ya?ml|json|md|sh|toml)\b")


def _names_something(line: str) -> bool:
    """Whether a line states a finding rather than announcing that one exists.

    The label guard above catches "Summary of the strongest reason:". It does not catch the sentence that
    follows a heading in a well-written review: "I inspected the actual code and assets behind each criterion
    rather than trusting the citations, and found a real reason the completion does not satisfy the operator's
    request." That is long and has no trailing colon, so it became the criterion - and it names nothing, so the
    three agents that picked it up could only guess, produced twenty-odd files apiece, and the attempt budget
    parked the request. A finding a builder can act on says which file, module or asset is wrong; a preamble
    describes the reviewing. Naming a thing is the difference, and these reviewers write those names in
    backticks or as filenames.
    """
    return bool(_NAMES_SOMETHING.search(line))


# 2026-09-13: `_review_brief` asks a reviewer to name a required runtime/toolchain, when the gap it found needs
# one, on its own `TOOLCHAIN:` line - exactly this shape, so extracting it is a literal match rather than a
# guess at free prose. Deliberately excluded from the headline search below: a short "TOOLCHAIN: X" line would
# otherwise either get swept up as the criterion's whole text (if it happened to clear the length guard) or, at
# 36 characters for the actual r-5795501a case, be silently treated as a label and dropped either way.
_TOOLCHAIN_LINE = re.compile(r"(?im)^\s*toolchain:\s*(.+?)\s*$")


def _toolchain_from_finding(finding: str) -> str | None:
    match = _TOOLCHAIN_LINE.search(finding)
    return match.group(1).strip() or None if match else None


def _criterion_from_finding(root: Path, request_id: str, finding: str) -> bool:
    """Turn a blocking review into one unmet criterion, unless its finding is already recorded.

    The same objection must not accumulate a new criterion on every beat: an hourly loop would bury the request
    under identical demands and never finish any of them. One open review criterion at a time is enough, because
    until it is met the gate will refuse for the same reason anyway.
    """
    request = requests.get(root, request_id)
    if request is None:
        return False
    if any(c.text.startswith(_REVIEW_CRITERION_PREFIX) and not c.met for c in request.criteria):
        return False
    toolchain = _toolchain_from_finding(finding)
    # The first line that actually says something. A review opens with headings and label lines ("Summary of the
    # strongest reason:"), and taking the first non-heading line produced a criterion reading "…strongest
    # reason:" — a demand with the demand missing, which is worthless to whoever builds against it.
    headline, fallback = "", ""
    for raw in finding.splitlines():
        line = raw.strip().lstrip("#").strip().lstrip("*").strip()
        if not line or line.startswith(("---", "===")) or _TOOLCHAIN_LINE.match(line):
            continue
        if line.endswith(":") or len(line) < 40:
            continue  # a label, not the finding it labels
        fallback = fallback or line
        if _names_something(line):
            headline = line
            break
    headline = headline or fallback or " ".join(finding.split())[:300]
    requests.add_criteria(
        root, request_id,
        [requests.Criterion(
            text=f"{_REVIEW_CRITERION_PREFIX}{headline[:300]}", source="engine", toolchain=toolchain,
        )],
    )
    return True


def _default_review_agent(root: Path) -> Any:
    """The read-only agent the completion gate reviews with, built the way the CLI builds it. A machine with no
    coding agent installed returns empty findings, which the gate treats as a review that did not do its job
    and refuses on — the fail-closed direction, and the right one for an unattended loop."""
    from pravrudhi.agents.registry import build_agent as make_agent

    def dispatch(task: Any) -> str:
        agent = make_agent(root, "claude-code", "sonnet")
        if agent is None:
            return ""
        workspace = agent.create_workspace(task.task_id)
        run = agent.run(task.prompt, workspace, timeout_s=task.timeout_s)
        agent.stop(workspace)
        return str(run.text)

    return dispatch


def _beat_completion_gate(root: Path, request_id: str) -> ActionResult:
    """Run the completion gate on a fully evidenced request, and act on either answer.

    Passing closes the request, which is what the operator delegated. Refusing means the work is not done —
    so the request goes back to `in_progress` carrying the reviewer's own finding as its note. That is not
    bookkeeping: while it sits at `delivered` it is "awaiting the gate" and every future beat chooses it again,
    which is exactly how this loop wedged. Back at `in_progress` its unmet work is what the next beat sees, and
    the engine moves.
    """
    from pravrudhi.application import completion

    # Check if the gate is already stalled (spent its attempt budget)
    if gate_stalled(root, request_id):
        return (
            {"request": request_id},
            f"the completion gate on {request_id} has stalled after {MAX_GATE_ATTEMPTS} attempts; leaving it for the operator",
            {"kind": "gate", "ran": False, "stalled": True, "attempts": gate_attempts(root, request_id)},
        )

    record_gate_attempt(root, request_id)

    try:
        result = completion.gate(root, request_id, dispatch=_default_review_agent(root), e2e="uv run pytest -q")
    except Exception as error:  # noqa: BLE001 (a gate that cannot run must not stop the heartbeat)
        return (
            {"request": request_id},
            f"the completion gate could not run on {request_id}: {error}",
            {"kind": "gate", "ran": False, "error": str(error), "attempts": gate_attempts(root, request_id)},
        )

    if result.passed:
        requests.advance(root, request_id, "verified", note=result.reason)
        return (
            {"request": request_id},
            f"{request_id} passed the completion gate and is verified",
            {"kind": "gate", "ran": True, "passed": True},
        )

    finding = (result.review.findings.strip() if result.review is not None else "") or result.reason

    # A blocking review does not mean the criteria are met and something else is wrong. It means the criteria
    # were too narrow — the reviewer's whole job is to find what the acceptance wording let through. So the
    # finding becomes an unmet criterion, which is what gives the next beat something to build.
    #
    # Without this the request only oscillates: refused back to `in_progress`, called "ready to move" because
    # every existing criterion still carries evidence, advanced to `delivered`, refused again, forever.
    added = _criterion_from_finding(root, request_id, finding)
    requests.advance(root, request_id, "in_progress", note=f"completion gate refused: {finding}"[:4000])
    return (
        {"request": request_id},
        f"{request_id} did not pass the completion gate and is building again: {result.reason}",
        {"kind": "gate", "ran": True, "passed": False, "reason": result.reason, "criterion_added": added},
    )


def _triage_complete(root: Path) -> Callable[[str], str] | None:
    """The chat seat used to decompose a prose ask, or `None` when none is configured or reachable.

    Model access goes through the OpenAI-compatible client, and the criteria come back under
    `requests.CRITERIA_SCHEMA` so the answer is a closed array rather than prose to be parsed. `None` is a
    normal outcome, not a fault: triage then falls back to the deterministic drafter.
    """
    with contextlib.suppress(Exception):
        from pravrudhi.application.chat import chat_endpoint
        from pravrudhi.models.openai_compat import ChatClient

        client = ChatClient(
            chat_endpoint(),
            model=os.environ.get("PRAVRUDHI_CHAT_MODEL", "").strip() or "local",
            api_key=os.environ.get("PRAVRUDHI_CHAT_API_KEY", "").strip() or None,
        )

        def complete(prompt: str) -> str:
            result = client.chat(
                [{"role": "user", "content": prompt}],
                temperature=0.2, max_tokens=1024, json_schema=requests.CRITERIA_SCHEMA,
            )
            return str(result.text)

        # Reachability is checked HERE, not on first use: an unreachable endpoint used to make `decompose_ask`
        # return [] on every ask, which the caller could not tell from "the model read it and found nothing",
        # so every prose ask got the verbatim fallback and the fleet's own seats were never asked.
        client.chat([{"role": "user", "content": "reply with the single word ok"}], temperature=0.0, max_tokens=4)
        return complete
    return _fleet_complete(root)


#: The seats triage may fall back to when no chat endpoint answers, in order. The loop's own CLI seats can
#: decompose an ask as well as a hosted model can, and the operator asked that the fleet be used.
_TRIAGE_VENDORS: tuple[str, ...] = ("claude-cli", "codex-cli")


def _fleet_complete(root: Path) -> Callable[[str], str] | None:
    """Decompose through the first CLI seat that is installed, or `None` when there is none.

    Only for an initialised workspace: a bare directory (every test's `tmp_path`) has no fleet, and a triage
    that phoned a real seat from a unit test would spend the operator's quota on "step up to bigger things".
    """
    if not (Path(root) / ".pravrudhi" / "config.yaml").exists():
        return None
    with contextlib.suppress(Exception):
        from pravrudhi.application import nyaya, panel

        ready = [v["id"] for v in nyaya.available_vendors(root, _TRIAGE_VENDORS) if v["available"]]
        if not ready:
            return None
        vendor = panel.VENDORS[ready[0]]

        def complete(prompt: str) -> str:
            text = panel.ask_vendor(vendor, prompt + "\n\nReply with the JSON object only.").text
            start, end = text.find("{"), text.rfind("}")
            return text[start : end + 1] if start >= 0 and end > start else text

        return complete
    return None


def _beat_triage(root: Path, *, complete: Callable[[str], str] | None = None) -> ActionResult:
    """Nothing has criteria to work, so the work is giving an ask some.

    This branch used to report "every captured request is verified; nothing is owed". That sentence was false
    whenever an ask sat in `captured`, and on 2026-09-09 it was false twenty-eight times over: `next_obligation`
    filters on `r.open and r.criteria`, so every undrafted ask was invisible to it, and the loop described that
    blindness as completion. A drive that cannot see work must not conclude there is none.

    Drafting is one beat's action and dispatching is the next one's. Keeping them apart means the criteria the
    engine wrote are on the record, and readable, before anything is paid to build against them.
    """
    pending = requests.untriaged(root)
    if not pending:
        return None, "every captured request is verified; nothing is owed", None
    model = complete if complete is not None else _triage_complete(root)
    for request in pending:
        triaged = requests.triage(root, request.id, complete=model)
        if triaged is None:
            continue  # states nothing to draft from; the next ask may
        texts = [c.text for c in triaged.criteria]
        return (
            {"request": request.id},
            f"{request.id} had no acceptance criteria, so the loop could not see it; "
            f"drafted {len(texts)} from the ask",
            {"kind": "triage", "request": request.id, "criteria": texts},
        )
    return (
        None,
        f"{len(pending)} captured ask(s) state nothing the engine can draft a criterion from; "
        f"they need the operator's words, not another beat",
        None,
    )


#: A backticked, bare `pravrudhi <subcommand>` invocation (`pravrudhi routes`, `pravrudhi agents`) - not a
#: general identifier match, just the one shape a CLI command name takes in a criterion's own text.
_CLI_COMMAND_RE = re.compile(r"^pravrudhi\s+[a-z][\w-]*$")

#: Deliberately just the bare word - specific enough on its own that a criterion mentioning it almost always
#: means a real API route, unlike "pravrudhi" (the project's own name), which needs the backtick+shape guard
#: above to avoid firing on ordinary prose.
_ENDPOINT_RE = re.compile(r"\bendpoint\b", re.IGNORECASE)


def build_paths_for(text: str, *, root: Path | None = None) -> tuple[str, ...]:
    """Extract repository paths from criterion text and widen to directory globs.

    Returns paths under allowed prefixes - this root's own declaration (`.pravrudhi/config.yaml`'s `build:` block,
    `build_config.resolved_allowed_prefixes`) when it has one, the engine's own set otherwise (src/, tests/,
    app/frontend/src/, scripts/, docs/, configs/, plugin/). Returns () if any named path is under protected
    prefixes, or if a declaring root's criterion names nothing under a prefix it declared.

    Recognized forms:
    - Backticked paths: `src/foo.py` -> src/*
    - Bare filenames: "update utils.py" (under allowed dirs) - engine defaults only, see below
    - tests/* is always included - engine defaults only; a declaring root says what it needs itself
    """
    from pravrudhi.application import build_config
    from pravrudhi.application.selfbuild import PROTECTED_PREFIXES

    if not text or not text.strip():
        return ()

    # Extract backticked paths. A trailing backtick with no partner is a name whose end was cut off (every
    # criterion drafted before 2026-09-11 was clipped at 300 characters, and one ended in `docs/usage.); what
    # remains of it still says which directory the work is in, so it counts.
    backticked = re.findall(r'`([^`]+)`', text)
    if text.count("`") % 2:
        tail = text[text.rfind("`") + 1:].strip()
        if tail and "/" in tail and " " not in tail:
            backticked.append(tail)

    # Also look for bare Python/TypeScript/shell/yaml/markdown file references
    # This is more forgiving to capture mentions like "update handler.py" or "create test_foo.py"
    bare_files = re.findall(r'\b([\w_-]+\.(?:py|ts|tsx|sh|yaml|yml|md))\b', text)

    all_paths = list(backticked) + list(bare_files)

    # Check if any path is under protected prefixes
    for path in all_paths:
        if any(path.startswith(prefix) for prefix in PROTECTED_PREFIXES):
            return ()

    declared = build_config.load_build_config(root).allowed_prefixes if root is not None else ()
    if declared:
        # A root that declared its own prefixes said what it needs; this does not also guess at bare
        # filenames or add tests/* uninvited (a JS/TS repo may have no tests/ directory at all).
        widened = {
            f"{prefix.rstrip('/')}/*"
            for path in all_paths for prefix in declared if path.strip().startswith(prefix)
        }
        return tuple(sorted(widened))

    # Widen paths to directory globs and normalize
    widened = set()

    for path in all_paths:
        path = path.strip()
        if not path:
            continue

        # If it's a file, widen to directory
        if "/" in path or "." in path:
            parts = path.split("/")
            if parts[0] in ("src", "tests", "app", "scripts", "docs", "configs", "plugin"):
                widened.add(f"{parts[0]}/*")
            elif path.startswith("app/frontend/"):
                widened.add("app/frontend/src/*")
        else:
            # Bare filename - try to infer from context or add tests
            if path.endswith(".py"):
                widened.add("src/*")
            elif path.startswith("test"):
                widened.add("tests/*")

    # cli-lead, 2026-09-14: r-1977143a criterion 2 asks for `pravrudhi routes`/`pravrudhi agents` output and
    # "an endpoint" serving the same data, but names no file path for either - only `configs/seats.yaml` is
    # backticked, so build_paths_for gave the dispatch write access to `configs/*` and `tests/*` alone. A
    # build-mode dispatch could then never touch the CLI or API code the criterion actually needs, and every
    # attempt could only write a spec-shaped test in the one place it *could* write - which the xfail-escape
    # fix (87495d3) correctly stopped disguising as progress, surfacing this as the real blocker instead.
    #
    # Two narrow, bounded rules, not a general "infer any mentioned identifier's file" (that IS the can of
    # worms a heuristic deciding a dispatch's write scope must not open): a backticked `pravrudhi <subcommand>`
    # invocation names the one module every CLI command lives in; the word "endpoint" anywhere in the text
    # names the one module every API route lives in. Restricted to backticked spans for the CLI rule
    # specifically, because "pravrudhi" bare in prose (the project's own name) is common and would falsely
    # widen scope on criteria that never asked for it; "endpoint" is specific enough not to need that guard.
    if any(_CLI_COMMAND_RE.fullmatch(p.strip()) for p in backticked):
        widened.add("src/pravrudhi/cli/app.py")
    if _ENDPOINT_RE.search(text):
        widened.add("src/pravrudhi/api/server.py")

    # Always include tests
    widened.add("tests/*")

    return tuple(sorted(widened))


_BUILD_TIER = "design"
"""Real code is design-tier work: the routing table names the seats that may write it."""

from pravrudhi.application.integrate import BUILD_VALIDATE, COMMIT_IDENTITY  # noqa: E402  one command for worktree and main tree


def _resolved_build_validate(root: Path) -> str:
    """The command a build-mode criterion in `root` validates with: its own declaration
    (`.pravrudhi/config.yaml`'s `build.validate`, r-9c8646fc) when it has one, this module's own `BUILD_VALIDATE`
    otherwise - read as `heartbeat.BUILD_VALIDATE` rather than `integrate.BUILD_VALIDATE` directly, so a caller
    (a test, or a future override) that patches this module's constant is still the one this function honours."""
    from pravrudhi.application import build_config

    return build_config.load_build_config(root).validate or BUILD_VALIDATE


def _selfbuild_policy(root: Path) -> Policy:
    """The write policy a build-mode dispatch runs under: the engine's own `selfbuild` preset
    (`sandbox_policies.yaml`), narrowed for a root that has declared its own build loop (r-9c8646fc).

    `apply_policy` sets a task's `validate` and intersects its `allowed_paths` against the POLICY's own, not the
    task's - the `selfbuild` preset's are `src/pravrudhi/**`, `tests/**` and the engine's other own directories,
    so a build task correctly scoped to `frontend/*` by `build_paths_for` would still be narrowed to nothing by
    a policy that has never heard of `frontend/`, and its own hardcoded validate would still run the engine's
    test suite regardless of what `TaskSpec.validate` said. A declaring root gets the same preset with its
    `allowed_paths` and `validate` replaced by its own declaration; a root that has not declared one gets the
    preset's `allowed_paths` but `_resolved_build_validate(root)` for its `validate` (below), not the YAML
    preset's own literal.

    2026-09-15, ADR-0056: the preset's own `validate:` string is a second, hand-maintained copy of
    `integrate.BUILD_VALIDATE` (its comment says as much), and it had already drifted - `BUILD_VALIDATE` grew
    the `--deselect` flags this ADR added, and this file's copy did not, so every build-mode dispatch went on
    running the three tripwire tests this ADR moved off the integration gate, unaffected by the fix that was
    meant to reach exactly this path. Routing through `_resolved_build_validate` instead of the preset's own
    string removes the second copy rather than editing it to match once more, which is the failure mode a
    literal string in a YAML file cannot be relied on not to repeat.
    """
    from pravrudhi.application import build_config

    policy = policy_for("selfbuild")
    declared = build_config.load_build_config(root)
    if not declared.allowed_prefixes and not declared.validate:
        return replace(policy, validate=_resolved_build_validate(root))
    prefixes = declared.allowed_prefixes or build_config.DEFAULT_PREFIXES
    return replace(
        policy,
        allowed_paths=tuple(f"{p.rstrip('/')}/*" for p in prefixes),
        validate=declared.validate or policy.validate,
    )


def _build_prompt(
    request_text: str, criterion_text: str, paths: tuple[str, ...], validate: str, *, prior: str = "",
    toolchain: str | None = None,
) -> str:
    fell_short = f"A previous attempt was judged NOT to meet this criterion because: {prior}\n\n" if prior else ""
    required = f"Required toolchain: {toolchain}\n\n" if toolchain else ""
    return (
        f"Operator request (verbatim): {request_text}\n\n"
        f"Acceptance criterion to deliver: {criterion_text}\n\n"
        f"{required}"
        f"{fell_short}"
        "You are MAKING this change in the engine's own source, not proposing it. House rules: a failing test "
        "first, then the change; constants in configs/ or an existing constants module, never magic numbers in "
        "code; Sanskrit primary keys in identifiers where the module already uses them; no new dependencies. "
        "\"A failing test first\" means the first commit's test fails, then your change makes it pass by the "
        "end of this dispatch - it does not mean stopping once the test exists. A test file where every case is "
        "marked `xfail`/`skip` (or otherwise never asserts the real behavior) is a specification of the "
        "criterion, not evidence it is met, and `validate` passing on such a file proves nothing about whether "
        "you implemented anything; finish the implementation until the tests you wrote pass for real. "
        "You may write only under: " + ", ".join(paths) + ". You may never write under pravrudhi_kernel/, "
        "research/, gates/ or .pravrudhi/, and no number you state may be presented as a result. "
        f"Before you finish, `{validate}` must pass in your worktree. Do not commit."
    )


#: `build_paths_for`'s own default-prefix branch always adds `tests/*` (see its docstring and
#: `TestBuildPathsFor.test_tests_glob_included`) even when nothing else was recognised in the text - a
#: deliberate filler for a genuine build dispatch's OWN scope (it may always touch its tests), not a signal
#: that a real path was named. `dispatch_mode` must tell the two apart: r-3981d7e0 criterion 3 named nothing
#: but `proposals/prabhasa-nyaya/harness/INSTALL.md` (not a recognised prefix) and mentioned "INSTALL.md" in
#: prose, so `build_paths_for` returned exactly this filler and nothing else - yet `if not paths` never caught
#: it, because the filler made `paths` non-empty regardless.
_ONLY_THE_TESTS_FILLER: frozenset[str] = frozenset({"tests/*"})

# A backticked, dotted identifier: `pravrudhi.agents.alibaba_agent`, `notifications.record()`,
# `messaging.resolve_telegram`. This codebase's own criteria favour naming a Python module, function or
# attribute this way over spelling out the file it lives in with a slash - r-dfff1a3d c1 and r-0704b2a0 c0
# (2026-09-12) named only references shaped like this and dispatched as proposal twice each, because neither
# `build_paths_for` nor the code-extension/prefix checks below ever look at a reference with no slash in it.
_DOTTED_REFERENCE = re.compile(r"`([a-zA-Z_][a-zA-Z0-9_]*(?:\.[a-zA-Z_][a-zA-Z0-9_]*)+)(\(\))?`")

# The tail of a two-segment dotted match this common in prose without ever meaning code: a session-closure or
# config filename (`HANDOFF.md`, `routing.yaml`, `pyproject.toml`). A three-or-more-segment match
# (`pravrudhi.agents.alibaba_agent`) or a trailing call (`notifications.record()`) is unambiguous either way,
# so this only screens the two-segment case; extensions the existing `code_extensions` regex already covers
# below are included so a bare `.py` mention is not double-counted as a *reference* instead of a *file*.
_NOT_A_PYTHON_REFERENCE_TAIL = frozenset({
    "md", "yaml", "yml", "json", "jsonl", "toml", "txt", "csv", "service", "timer", "lock", "cfg", "ini",
    "py", "ts", "tsx", "js", "sh",
})


def _names_a_python_reference(text: str) -> bool:
    """Whether `text` backtick-names a Python module, function or attribute path with no slash in it - the
    shape `pravrudhi.agents.alibaba_agent`, `notifications.record()` and `messaging.resolve_telegram` share,
    and a slashed file path or a bare session/config filename (`HANDOFF.md`) does not."""
    for match in _DOTTED_REFERENCE.finditer(text):
        dotted, call = match.group(1), match.group(2)
        if call:
            return True
        segments = dotted.split(".")
        if len(segments) >= 3 or segments[-1].lower() not in _NOT_A_PYTHON_REFERENCE_TAIL:
            return True
    return False


def dispatch_mode(criterion: requests.Criterion, *, root: Path | None = None) -> str:
    """Determine dispatch mode: 'build' or 'proposal' (default).

    Returns 'build' when:
    - criterion.mode is explicitly set to "build", OR
    - criterion.mode is unset (defaults to "proposal") AND build_paths_for names something beyond its own
      `tests/*` filler (see `_ONLY_THE_TESTS_FILLER`) AND the text names a code file (.py, .ts, .tsx, .sh,
      .yaml, .md), a backticked path under a prefix this root (`root`) may build under, or a backticked
      Python module/function/attribute reference with no slash in it (`_names_a_python_reference`) - its own
      declared `allowed_prefixes` when it has one, the engine's own set otherwise

    Otherwise returns 'proposal'.
    """
    # Explicit build mode always uses build
    if criterion.mode == "build":
        return "build"

    # Auto-detect: check if a REAL path is named - build_paths_for's own tests/*-only filler is not one, unless
    # the text also names a Python reference the filler alone cannot represent (see _names_a_python_reference).
    paths = build_paths_for(criterion.text, root=root)
    if not paths:
        return "proposal"
    names_python_reference = _names_a_python_reference(criterion.text)
    if set(paths) <= _ONLY_THE_TESTS_FILLER and not names_python_reference:
        return "proposal"

    from pravrudhi.application import build_config

    # A code file, or a backticked path under a prefix the loop may write under (a directory counts: r-35e8ce7b
    # criterion 0 named `docs/blueprint/02-design/` and a `.pdf`, went the proposal way twice, and the judge
    # refused it twice for the sandbox reason).
    code_extensions = r'\.(py|ts|tsx|js|sh|yaml|yml|md)\b'  # .js: the desktop shell (app/desktop) is plain JS
    prefixes = build_config.resolved_allowed_prefixes(root)
    prefix_pattern = r"`(?:" + "|".join(re.escape(p.rstrip("/")) for p in prefixes) + r")/"
    if names_python_reference or re.search(code_extensions, criterion.text) or re.search(prefix_pattern, criterion.text):
        return "build"

    return "proposal"


# A one-line check on the previous judgement (session-3, 2026-09-12): if it named the deliverable's mode as
# the problem and this beat would still dispatch in that mode, retrying only reproduces the identical rejection.
# Deliberately narrow, matching the one confirmed shape: a proposal-mode dispatch writes a draft to a scratch
# directory, never runs it, and the judge correctly refuses a claim of "proves" or "asserts" against a draft.
_MODE_BLOCKER_MARKERS: tuple[str, ...] = ("a draft is not an executed test",)


def unbuildable(
    root: Path, criterion: requests.Criterion, *, request_id: str = "", index: int = 0
) -> str | None:
    """Why no dispatch can meet this criterion in this checkout, or None when one might.

    Two shapes cost the loop three paid attempts each before anyone read the reason. A criterion that names the
    kernel: T0 changes are an ADR accepted under the delegation before the commit (ADR-0047), which a sandboxed
    agent cannot produce, so build_paths_for() returns () and the proposal fallback writes a README the gate then
    refuses. And a criterion whose named paths are gitignored here (docs/blueprint/ is local): the worktree can
    write them and integrate cannot commit them, so "met" can never carry a commit.

    `request_id`/`index` are optional and default to inactive (no `request_id` means the mode-blocker check
    below never runs), so every existing caller that checks only the structural reasons above is unaffected.
    """
    if request_id:
        last = _last_judgement(root, request_id, index)
        if any(marker in last for marker in _MODE_BLOCKER_MARKERS) and dispatch_mode(criterion, root=root) == "proposal":
            return (
                "the previous attempt's own judgement said the mode was the blocker, and this beat would "
                f"dispatch it in that same mode again: {last!r}"
            )

    from pravrudhi.application import build_config
    from pravrudhi.application.selfbuild import PROTECTED_PREFIXES

    named = [p.strip() for p in re.findall(r"`([^`]+)`", criterion.text) if "/" in p]
    protected = [p for p in named if any(p.startswith(prefix) for prefix in PROTECTED_PREFIXES)]
    if protected:
        return (
            f"names {', '.join(sorted(set(protected)))}: a change under a protected prefix ({', '.join(PROTECTED_PREFIXES)}) "
            "is an ADR accepted before the commit (ADR-0047) or a kernel-computed result, never a swarm dispatch"
        )
    declared_prefixes = build_config.load_build_config(root).allowed_prefixes
    if not declared_prefixes:
        # This check is about a root running the engine from a wheel, with no engine source of its own to
        # change - it does not apply to a root that has declared its OWN build loop (r-9c8646fc): naming a
        # `.tsx` file there is that root's own source, not a wayward reference to this engine's.
        engine_like = [
            p for p in named
            if p.split("/")[0] in ("src", "pravrudhi", "app", "scripts", "plugin") or p.endswith((".py", ".ts", ".tsx"))
        ]
        if engine_like and not (root / "src").is_dir():
            # A product install runs the engine from a wheel: there is no engine source in this root to change,
            # and a worktree here can only produce files nothing imports. The ask belongs upstream in studio.
            return (
                f"names engine source ({', '.join(sorted(set(engine_like))[:4])}) and this root has no engine "
                "source checkout (no src/ tree): a wheel install cannot build the engine; it belongs upstream "
                "in the studio backlog"
            )
    prefixes = declared_prefixes or build_config.DEFAULT_PREFIXES
    repo_paths = [p for p in named if any(p.startswith(prefix) for prefix in prefixes)]
    if repo_paths and (root / ".git").exists():
        probe = subprocess.run(
            ["git", "check-ignore", "--", *repo_paths], cwd=root, capture_output=True, text=True, check=False,
        )
        ignored = [line for line in probe.stdout.splitlines() if line]
        if ignored and len(ignored) == len(set(repo_paths)):
            return (
                f"every path it names is ignored in this checkout ({', '.join(ignored)}): a worktree can write "
                "them and integrate cannot commit them, so no dispatch can meet it here"
            )
    return None


_MEMINFO_PATH = Path("/proc/meminfo")


def _available_memory_gb() -> float | None:
    """`MemAvailable` from `/proc/meminfo`, in GB, or `None` when it cannot be read (not Linux, or the file is
    missing) - the caller treats that the same as "below the floor", the same fail-closed direction as every
    other unclear answer in this module."""
    try:
        text = _MEMINFO_PATH.read_text()
    except OSError:
        return None
    for line in text.splitlines():
        if line.startswith("MemAvailable:"):
            parts = line.split()
            if len(parts) >= 2 and parts[1].isdigit():
                return int(parts[1]) / (1024 * 1024)
    return None


def _effective_width(root: Path) -> tuple[int, str]:
    """How many independent criteria this beat may dispatch at once, and why it was narrowed if it was (S6).

    `limits.yaml`'s `heartbeat.concurrent_dispatches` is the configured width; the same file's
    `heartbeat.min_available_gb` is a host-RAM floor read fresh every beat, because each concurrent dispatch
    spawns its own coding-agent process and its MCP/plugin servers, and this box has run under earlyoom pressure.
    Below the floor - or when it cannot even be measured - the beat runs one dispatch, same as every beat before
    this existed.
    """
    configured = availability.concurrent_dispatches()
    if configured <= 1:
        return configured, ""
    floor = availability.min_available_gb()
    measured = _available_memory_gb()
    if measured is None:
        return 1, f"MemAvailable could not be read; narrowed from {configured} to 1"
    if measured < floor:
        return 1, f"MemAvailable {measured:.1f}GB is below the {floor:.1f}GB floor; narrowed from {configured} to 1"
    return configured, ""


def _last_beat_requests(root: Path) -> frozenset[str]:
    """The request id(s) the immediately previous beat dispatched against, for rotation (S6) to prefer a
    request that is not one of these when another is eligible. Read from `heartbeat.jsonl` (`history`), not a
    new state file: `chose` is a single `{"request": ..., "criterion": ...}` dict for one dispatch (every beat
    before S6, and every single-dispatch beat since) or a list of them for a beat that dispatched more than
    one; any other shape (triage, parked, a diagnostic drive, no prior beat at all) names no request, and
    rotation has nothing to prefer against."""
    prior = history(root, n=1)
    if not prior:
        return frozenset()
    chose = prior[-1].chose
    if isinstance(chose, dict):
        rid = chose.get("request")
        return frozenset({rid}) if rid else frozenset()
    if isinstance(chose, list):
        return frozenset(str(c["request"]) for c in chose if isinstance(c, dict) and c.get("request"))
    return frozenset()


def _task_for_criterion(
    root: Path, request: requests.Request, criterion: requests.Criterion, index: int, mode: str,
) -> tuple[str, swarm.SwarmTask]:
    """Build the scoped `SwarmTask` for one criterion. Extracted from what was `_beat_obligations`'s own inline
    dispatch-building (S6), so a beat that dispatches more than one criterion builds each exactly as the
    single-dispatch path always has - this function's body is unchanged from that inline code."""
    task_id = f"request:{request.id}:{index}"
    if mode == "build":
        paths = build_paths_for(criterion.text, root=root)
        build_validate = _resolved_build_validate(root)
        spec = TaskSpec(
            task_id=task_id,
            prompt=_build_prompt(request.text, criterion.text, paths, build_validate,
                                 prior=_last_judgement(root, request.id, index), toolchain=criterion.toolchain),
            allowed_paths=paths,
            validate=build_validate,
        )
        task = swarm.SwarmTask(spec, _BUILD_TIER, why=f"oldest unmet criterion of request {request.id} (build)")
        scoped = replace(task, spec=apply_policy(task.spec, _selfbuild_policy(root)))
    else:
        scratch = _obligation_scratch(request.id, index)
        (root / scratch).mkdir(parents=True, exist_ok=True)
        validate = f'test -n "$(ls -A {scratch})" && uv run python -m compileall -q {scratch}'
        spec = TaskSpec(
            task_id=task_id,
            prompt=_obligation_prompt(request.text, criterion.text, scratch, validate,
                                      prior=_last_judgement(root, request.id, index), toolchain=criterion.toolchain),
            allowed_paths=(f"{scratch}/*",),
            validate=validate,
        )
        task = swarm.SwarmTask(spec, _OBLIGATION_TIER, why=f"oldest unmet criterion of request {request.id}")
        scoped = replace(task, spec=apply_policy(task.spec, policy_for("proposal")))
    return task_id, scoped


def _more_candidates(
    root: Path, count: int, *, exclude_requests: set[str], prior_requests: frozenset[str],
) -> list[tuple[requests.Request, requests.Criterion, int]]:
    """Up to `count` more unmet, unparked criteria for this beat's wave (S6), each from a request not already
    picked this beat (`requests.next_unmet`'s own `exclude`) and not itself unbuildable or stalled - those are
    left for the ordinary loop above to paper-stall when one becomes the single oldest pick on some future beat,
    rather than spending that bookkeeping twice.

    Rotation: a request `prior_requests` (the previous beat's own picks, from `_last_beat_requests`) already
    dispatched against is preferred against only once nothing fresher is eligible - two passes, the first
    excluding those requests entirely, the second (only run if slots remain) allowing them.
    """
    picked: list[tuple[requests.Request, requests.Criterion, int]] = []
    excluded = set(exclude_requests)
    for prefer_fresh in (True, False):
        if len(picked) >= count:
            break
        skip = set(excluded) | (set(prior_requests) if prefer_fresh else set())
        while len(picked) < count:
            found = requests.next_unmet(root, exclude=frozenset(skip))
            if found is None:
                break
            req, crit, idx = found
            excluded.add(req.id)
            skip.add(req.id)
            if stalled(root, req.id, idx) or unbuildable(root, crit, request_id=req.id, index=idx) is not None:
                continue
            picked.append((req, crit, idx))
    return picked


def _apply_verdict(
    root: Path, request: requests.Request, criterion: requests.Criterion, index: int, mode: str, task_id: str,
    verdict: Any, judge: Any,
) -> tuple[dict[str, str], str, dict[str, Any]]:
    """Everything `_beat_obligations` used to do after `swarm.run_wave` returned one verdict for one criterion:
    dispatch-failure bookkeeping, the judge, the CHARTER §6 backstop, and (on MET) integration or `requests.meet`.
    Extracted unchanged (S6) so a beat dispatching several criteria at once applies each one's result exactly as
    the single-dispatch path always has, in the same sequential order, one call per finished task."""
    chose = {"request": request.id, "criterion": str(index)}
    result: dict[str, Any] = {
        "accepted": verdict.accepted, "route": verdict.agent, "files": list(verdict.files),
        "reasons": list(verdict.reasons),
    }
    verb = "accepted" if verdict.accepted else "rejected"
    if not verdict.accepted:
        if _is_genuine_noop(verdict):
            # ADR-0053 §5: a "no change needed" report is a result, not a dispatch failure - it never touches
            # MAX_DISPATCH_FAILURES. The agent's claim is about the repository's existing state, and its own
            # worktree is empty, so the judge reads `root` (current main) instead of the usual per-task worktree.
            streak = record_noop(root, request.id, index)
            result["noop_streak"] = streak
            answer = (judge or _default_judge(root, workspace=root))(
                prompt=_judge_prompt(
                    request.text, criterion.text, [],
                    where="the repository's current main tree, since the agent reported nothing needed changing",
                )
            )
            met, why = _judged(answer)
            if met:
                unbacked = _first_unevidenced_claim(root, [])
                if unbacked is not None:
                    met = False
                    why = (
                        f"a produced file admits an unmeasured number ({unbacked!r}); CHARTER §6: no number is "
                        "stated that the ledger does not contain, and being honest about inventing one is not "
                        "an exception"
                    )
            result["judged"] = "met" if met else "not met"
            result["judgement"] = why
            if not met:
                clear_noop_streak(root, request.id, index)
                requests.note(root, request.id, _judgement_note(index, why))
                return (
                    chose,
                    f"dispatched request {request.id} criterion {index} (no change needed, judged not met): {why}",
                    result,
                )
            if streak < MAX_NOOP_STREAK:
                return (
                    chose,
                    f"dispatched request {request.id} criterion {index} (no change needed, "
                    f"{streak}/{MAX_NOOP_STREAK} consecutive): {why}",
                    result,
                )
            head = _current_head(root)
            requests.meet(
                root, request.id, index,
                [requests.Evidence(kind="commit", ref=head, note=f"already true as of {head}: {why}")],
            )
            clear_noop_streak(root, request.id, index)
            clear_attempts(root, request.id, index)
            return (
                chose,
                f"request {request.id} criterion {index} is already-met after {streak} consecutive no-ops: {why}",
                result,
            )
        wall = external_wall_reason(verdict.reasons)
        if wall is not None:
            # ADR-0053 §5 drew this line for a genuine no-op; the same line applies to a wall outside the
            # criterion's own reach (see `external_wall_reason`'s docstring). Never touches
            # MAX_DISPATCH_FAILURES, so the criterion is exactly as far from parked as it was before this beat.
            result["external_wall"] = wall
            return (
                chose,
                f"dispatched request {request.id} criterion {index} ({verb}, external wall: {wall}); "
                "not counted towards dispatch failures",
                result,
            )
        # H4: Dispatch-level failure (accepted=False before judge). Record separately, do not consume
        # a judged attempt. If dispatch failures are exhausted, park the criterion.
        dispatch_fails = record_dispatch_failure(root, request.id, index)
        result["dispatch_failures"] = dispatch_fails
        if verdict.validation_output:
            result["validation_output"] = verdict.validation_output[-VALIDATION_OUTPUT_TAIL:]
        if dispatch_failures_exhausted(root, request.id, index):
            return (
                chose,
                f"dispatched request {request.id} criterion {index} ({verb}, dispatch failed {dispatch_fails} times); "
                f"parked after {MAX_DISPATCH_FAILURES} dispatch failures",
                result,
            )
        return chose, f"dispatched request {request.id} criterion {index} ({verb})", result

    # Accepted says the diff stayed in scope and the validate command passed. It does not say the criterion is
    # satisfied, so the beat asks rather than assuming. Fail-closed: an unclear answer is not met.
    # H4: Now record the judged attempt, only after dispatch accepted and we will run the judge.
    record_attempt(root, request.id, index)
    from pravrudhi.agents.base import GitWorktreeMixin

    build_worktree: Path = root / ".worktrees" / f"agent-{GitWorktreeMixin.ref_safe(task_id)}"
    where = (
        "the agent's worktree, which is your working directory and holds the change (the repository root does not yet)"
        if mode == "build" else
        "the agent's worktree, which is your working directory and holds the proposal (the repository root does not yet)"
    )
    answer = (judge or _default_judge(root, workspace=build_worktree))(
        prompt=_judge_prompt(request.text, criterion.text, list(verdict.files), where=where))
    met, why = _judged(answer)
    if met:
        # A second, deterministic look, independent of whatever the judge said.
        unbacked = _first_unevidenced_claim(build_worktree, list(verdict.files))
        if unbacked is not None:
            met = False
            why = (
                f"a produced file admits an unmeasured number ({unbacked!r}); CHARTER §6: no number is stated "
                "that the ledger does not contain, and being honest about inventing one is not an exception"
            )
    result["judged"] = "met" if met else "not met"
    result["judgement"] = why
    if met:
        result["mode"] = mode
        if mode == "build":
            from pravrudhi.application import integrate

            worktree = root / ".worktrees" / f"agent-{GitWorktreeMixin.ref_safe(task_id)}"
            outcome = integrate.integrate_build_criterion(
                root, {task_id: worktree}, request.id, index,
                validate=_resolved_build_validate(root),
            )
            result["integration"] = outcome.to_dict()
            if not outcome.ok:
                return chose, f"request {request.id} criterion {index} judged met but not integrated: {outcome.why}", result
            clear_attempts(root, request.id, index)
            # ADR-0002 (pravrudhi-app): publish the branch now that this beat's rebase and this criterion's
            # integration have both already succeeded -- a push failure is recorded but never undoes the
            # integration or reopens the criterion; the next beat's rebase-then-push tries again.
            push_conflict = _push_loop_branch(root)
            result["published"] = push_conflict is None
            if push_conflict is not None:
                result["publish_detail"] = push_conflict
            return chose, f"request {request.id} criterion {index} is met and integrated as {outcome.commit}: {why}", result
        requests.meet(root, request.id, index,
                      [requests.Evidence(kind="file", ref=f, note="produced for this criterion")
                       for f in verdict.files])
        clear_attempts(root, request.id, index)
        return chose, f"request {request.id} criterion {index} is met: {why}", result

    # cli-lead, 2026-09-13: "nothing is learned by watching it fail twice at full price" when the incapability
    # is a fact about mode/policy knowable now, so this checks every not-met verdict rather than waiting for a
    # budget to exhaust - it may fire on the very first attempt.
    policy = _selfbuild_policy(root) if mode == "build" else policy_for("proposal")
    gap = structural_incapability(mode=mode, policy=policy, criterion_text=criterion.text, rejection_text=why)
    if gap is not None:
        requests.decline_criterion(
            root, request.id, index, why=f"structurally unreachable ({gap.category}): {gap.reason}",
        )
        result["structural_incapability"] = gap.category
        return (
            chose,
            f"request {request.id} criterion {index} declined ({gap.category}): {gap.reason}",
            result,
        )
    requests.note(root, request.id, _judgement_note(index, why))
    return chose, f"dispatched request {request.id} criterion {index} ({verb}, judged not met): {why}", result


def _beat_obligations(root: Path, dispatch: DispatchFn | None, *, judge: Any = None) -> ActionResult:
    """`seva` (obligations): the oldest unmet request criterion (`requests.next_unmet`), dispatched through the
    swarm exactly like a capability step, scoped to its own proposal scratch directory under `proposals/requests/`.

    When a criterion is in 'build' mode, it is dispatched with allowed_paths set to the paths the criterion
    names, under the 'selfbuild' sandbox policy. On MET, the worktree is integrated into the main tree,
    validated, and committed. On validation failure or conflict, files are restored and the criterion stays unmet."""
    owed = requests.next_obligation(root)
    if owed is None:
        return _beat_triage(root)
    if owed["kind"] == "verify_request":
        # Everything on this request is evidenced and it has not been through the gate, so the work is the gate,
        # not more building. Reporting "no request has an unmet criterion" and stopping was how the loop came to
        # say it had nothing to do while three requests were still owed.
        #
        # And then it ran the gate for nobody. Naming the command an operator could type is not doing the work:
        # every beat chose this same request, returned no result, and the engine idled for a day while its own
        # adversarial reviewer sat on a finding nobody had read. A beat that can only describe the next action
        # is not a heartbeat. So the gate runs here.
        return _beat_completion_gate(root, str(owed["request"]))
    if owed["kind"] == "parked_request":
        # Every unmet criterion on every request WITH criteria has spent its attempt budget. That is not the
        # same as nothing to do: an ask with no criteria is invisible to `next_obligation`, and on 2026-09-11
        # ninety of them sat captured while both loops reported the same parked request every hour for five
        # hours with `looked_at: []`. Giving one of them criteria is work this beat can do; only when there is
        # none left is "parked" the whole truth. `watchdog._parked_criteria` still reports the parked state.
        if requests.untriaged(root):
            return _beat_triage(root)
        return (
            {"request": str(owed["request"])},
            f"{owed['request']} is parked: {owed['description']}",
            {"kind": "parked", "criteria": str(owed["text"])},
        )
    if owed["kind"] == "advance_request":
        # Ready to move, so move it. Describing the move and returning nothing was the same failure as the
        # branch above, and together they oscillated: the gate refused a delivered request back to
        # `in_progress`, this branch called it ready, and neither ever changed anything.
        # Guarded even though `next_obligation` now agrees with the guard. A beat that raises kills the unit
        # for an hour, and the two disagreed silently for a day before anyone read the journal; a refusal here
        # is a thing to report, never a thing to crash on.
        #
        # 2026-09-14/15, web's diagnosis: TRANSITIONS has no direct captured/clarified/planned -> delivered
        # hop (only in_progress -> delivered), but nothing anywhere in this pipeline ever calls
        # advance(..., "in_progress") on its own -- every request sits at "captured" until something
        # deliberately moves it. So the instant every criterion on a still-captured request resolved, this
        # branch's one-hop "delivered" call was refused every single beat, and the loop re-selected the
        # same finished request forever instead of finding new work. The fix walks the same TRANSITIONS
        # table `advance` already enforces rather than adding a new edge to it: advancing to "in_progress"
        # first is a no-op if the request is already there (`advance` returns early when state == req.state)
        # and is a legal single hop from every other state `_obligation_for` can hand this branch (captured,
        # clarified, planned - `delivered` and `verified` never reach here, see the branches above and
        # Request.open).
        try:
            requests.advance(root, str(owed["request"]), "in_progress", note="ready to deliver")
            requests.advance(root, str(owed["request"]), "delivered", note="every criterion carries evidence")
        except requests.RequestError as e:
            return (
                {"request": str(owed["request"])},
                f"{owed['request']} looked ready but the state machine refused: {e}",
                {"kind": "advance_refused", "error": str(e)},
            )
        return (
            {"request": str(owed["request"])},
            f"{owed['request']} has evidence on every criterion and is now delivered, awaiting the gate",
            {"kind": "advance", "to": "delivered"},
        )
    paper: list[dict[str, Any]] = []
    while True:
        found = requests.next_unmet(root)
        if found is None:
            if paper:
                return (
                    {"request": paper[-1]["request"], "criterion": str(paper[-1]["criterion"])},
                    f"stalled {len(paper)} criterion(s) no dispatch here can meet, and nothing else is owed",
                    {"kind": "unbuildable", "stalled": paper, **paper[-1]},
                )
            return _beat_triage(root)  # pragma: no cover - next_obligation already answered meet_criterion
        request, criterion, index = found
        why_not = unbuildable(root, criterion, request_id=request.id, index=index)
        if why_not is None:
            break
        # Spend the budget on paper rather than on three model calls that cannot succeed, say why where the
        # operator and the next triage will read it, and keep going: stalling is bookkeeping, not the beat's
        # work. The first live beat with this check stalled one kernel criterion and went home for 20 minutes.
        while not stalled(root, request.id, index):
            record_attempt(root, request.id, index)
        requests.note(root, request.id, f"criterion {index} unbuildable: {why_not}")
        paper.append({"request": request.id, "criterion": index, "why": why_not, "criterion_text": criterion.text[:300]})
        if len(paper) >= MAX_PAPER_STALLS_PER_BEAT:
            return (
                {"request": request.id, "criterion": str(index)},
                f"stalled {len(paper)} criterion(s) no dispatch here can meet; the rest wait for the next beat",
                {"kind": "unbuildable", "stalled": paper, **paper[-1]},
            )
    if stalled(root, request.id, index):
        # Spent its budget: this loop has dispatched this exact criterion MAX_CRITERION_ATTEMPTS times without
        # moving it, so a further identical dispatch buys nothing and costs a real model call. Say so where the
        # operator will see it and let the beat spend itself elsewhere.
        return (
            {"request": request.id, "criterion": str(index)},
            f"{request.id} criterion {index} has stalled after {attempts(root, request.id, index)} attempts; "
            f"leaving it for the operator rather than paying to retry it again",
            {"kind": "stalled", "request": request.id, "criterion": index,
             "attempts": attempts(root, request.id, index), "criterion_text": criterion.text[:300]},
        )
    # S6: up to `width` independent criteria dispatched together - different requests, path-disjoint via
    # `swarm.plan` (the same conflict check a wave of objective steps already uses) - one worktree per dispatch
    # either way, since `_task_for_criterion` builds each exactly as the single-dispatch path always has.
    # `width == 1` (the default when the host-RAM floor narrows it, or `concurrent_dispatches` is configured to
    # 1) takes the identical single-task path this function has always taken: one entry, one wave of one task,
    # one verdict, one result - nothing about that path's behaviour changes here.
    width, width_note = _effective_width(root)
    picks = [(request, criterion, index)]
    if width > 1:
        prior_requests = _last_beat_requests(root)
        picks += _more_candidates(root, width - 1, exclude_requests={request.id}, prior_requests=prior_requests)

    specs: list[swarm.SwarmTask] = []
    by_task_id: dict[str, tuple[requests.Request, requests.Criterion, int, str]] = {}
    for req, crit, idx in picks:
        pick_mode = dispatch_mode(crit, root=root)
        task_id, scoped = _task_for_criterion(root, req, crit, idx, pick_mode)
        specs.append(scoped)
        by_task_id[task_id] = (req, crit, idx, pick_mode)

    waves, _conflicts = swarm.plan(specs)
    batch = waves[0] if waves else []

    build_agent = dispatch or _default_build_agent(root)
    # H4: Do NOT record attempt before dispatch. Dispatch-level failures (validation, workspace race)
    # return before judge runs and must not consume a judged attempt.
    verdicts = swarm.run_wave(build_agent, batch, log=lambda _msg: None, root=root)
    # `run_wave` collects verdicts via `as_completed` - completion order, not submission order - so a wave of
    # more than one task must match each verdict back to its task by id, never by zipped position. A wave of
    # exactly one is unambiguous by construction and needs no id at all, which keeps this reading `verdict.task_id`
    # only when there is more than one to tell apart - unchanged from what the single-dispatch path ever needed.
    verdicts_by_task_id = (
        {batch[0].spec.task_id: verdicts[0]} if len(verdicts) == 1 and batch
        else {v.task_id: v for v in verdicts}
    )

    results = []
    for task in batch:
        req, crit, idx, pick_mode = by_task_id[task.spec.task_id]
        verdict = verdicts_by_task_id[task.spec.task_id]
        results.append(_apply_verdict(root, req, crit, idx, pick_mode, task.spec.task_id, verdict, judge))

    chose: Chose
    result: dict[str, Any]
    if len(results) <= 1:
        chose, reason, result = results[0] if results else (None, "no criterion could be dispatched this beat", {})
    else:
        chose = [c for c, _r, _res in results]
        reason = f"dispatched {len(results)} independent criteria this beat: " + " | ".join(r for _c, r, _res in results)
        result = {"kind": "batch", "dispatches": [res for _c, _r, res in results]}
    if width_note:
        reason = f"{width_note}; {reason}"
    return chose, reason, result


# The cheapest-first order to try a failing doctor check's remedy in: (cost, remedy description). `gpu` is
# excluded because `doctor.run_doctor` reports it `ok=True` unconditionally, so it can never fail.
_CONTINUITY_REMEDIES: dict[str, tuple[int, str]] = {
    "initialised": (1, "run `pravrudhi init` to create the missing config or ledger"),
    "prereg": (2, "write the missing pre-registration file(s) under research/prereg/"),
    "pools": (3, "seal a pool so a manifest exists under .pravrudhi/kernel/pools"),
    "docker": (4, "install or start Docker so the sandbox runner is available"),
    "ledger": (5, "investigate and repair the ledger integrity failure before any further run"),
}
_DEFAULT_REMEDY_COST = 99


def _continuity_remedy(name: str) -> tuple[int, str]:
    return _CONTINUITY_REMEDIES.get(name, (_DEFAULT_REMEDY_COST, f"diagnose and repair the failing {name!r} check"))


def _beat_continuity(sthiti: kshudha.Drive) -> ActionResult:
    """`sthiti` (continuity): the cheapest failing doctor check's remedy, read from the drive's own `sources`
    (`doctor:<name>=ok|fail`, from `kshudha.sthiti_drive`) rather than re-running `doctor.run_doctor`. This never
    executes a repair itself — installing Docker or rewriting the ledger is not something a heartbeat does
    unattended — it only proposes which one to do next, same as every other beat action."""
    failing = [s.split(":", 1)[1].split("=", 1)[0] for s in sthiti.sources if s.endswith("=fail")]
    if not failing:
        return None, "no continuity check is currently failing; nothing to remedy", None
    name = min(failing, key=lambda n: (_continuity_remedy(n)[0], n))
    _, remedy = _continuity_remedy(name)
    chose = {"check": name}
    # "proposing", not "running": this beat deliberately executes nothing, and the previous wording said
    # otherwise once an hour for eight hours on the product workspace while the pool went unsealed and the
    # deficit never moved. The journal is what the operator reads to see whether the loop is working.
    reason = f"proposing the remedy for the failing {name!r} continuity check (not run here): {remedy}"
    return chose, reason, {"check": name, "remedy": remedy}


def _beat_diagnostic(drive: kshudha.Drive) -> ActionResult:
    """`pramana_navyata` (freshness) and `unnati_avakasha` (benchmark headroom) have no wired dispatch action in
    this codebase — no evidence-freshness source, no budgeted benchmark-trial runner — so winning never dispatches
    anything; it always produces this bounded, honest diagnostic instead of a fabricated action."""
    chose = {"drive": drive.wire_name}
    if drive.unknown:
        detail = drive.blocked_reason or "no source is wired into the engine yet"
    else:
        detail = f"deficit={drive.deficit:.4f} but no dispatch action is wired for {drive.wire_name} yet"
    reason = f"{drive.wire_name}: diagnostic only; {detail}"
    result = {"kind": "diagnostic", "unknown": drive.unknown, "sources": list(drive.sources)}
    return chose, reason, result


def _beat_resources(sadhana: kshudha.Drive) -> ActionResult:
    """`sadhana` (resources): there is no route to dispatch a usable coding-agent route into existence, so this
    records the desire once rather than dispatching a doomed action — used only when no other drive is eligible
    to take over this beat."""
    chose = {"drive": "resources"}
    reason = "no usable coding-agent route is available; recording the desire, nothing else is eligible to act"
    result = {"kind": "desire", "sources": list(sadhana.sources)}
    return chose, reason, result


def _dispatch_drive(
    drive_id: str, *, root: Path, config: HeartbeatConfig, dispatch: DispatchFn | None,
    drives_by_id: dict[str, kshudha.Drive],
) -> tuple[tuple[str, ...], Chose, str, dict[str, Any] | None]:
    """The action wired to one drive (never `sadhana`, which the caller resolves to a fallback drive first)."""
    if drive_id == "samarthya":
        return _beat_capability(root, config, dispatch)
    if drive_id == "seva":
        chose, reason, result = _beat_obligations(root, dispatch)
        return (), chose, reason, result
    if drive_id == "sthiti":
        chose, reason, result = _beat_continuity(drives_by_id["sthiti"])
        return (), chose, reason, result
    chose, reason, result = _beat_diagnostic(drives_by_id[drive_id])
    return (), chose, reason, result


def _next_eligible(appetite: kshudha.Appetite, exclude: str) -> str | None:
    """The drive `sadhana` yields to: the largest eligible measured deficit among the rest, falling back to an
    unknown drive worth a diagnostic, mirroring how `kshudha.select` itself ranks `largest_unmet` and diagnostics —
    without touching `kshudha.py`, since this is heartbeat's fallback, not the appetite's own selection."""
    candidates = [
        d for d in appetite.drives if d.id != exclude and d.eligible and d.deficit is not None and d.deficit > 0
    ]
    if candidates:
        candidates.sort(key=lambda d: (-d.pressure, d.id))
        return candidates[0].id
    diagnostics = sorted(
        (d for d in appetite.drives if d.id != exclude and d.unknown and d.weight > 0), key=lambda d: d.id,
    )
    return diagnostics[0].id if diagnostics else None


def beat(
    root: Path, *, dispatch: DispatchFn | None = None, probe: availability.ProbeFn | None = None,
    now: datetime | None = None,
) -> BeatRecord:
    """One heartbeat: measure the six drives (`kshudha.measure`), let them select which one wins
    (`kshudha.select`), and dispatch the action wired to that drive — never the heartbeat's own precedence rule.

    Before any of that, every route `availability.cooling` is still holding out is put in front of `probe`
    (`availability.reprobe_cooling`) and recovered on the spot if it answers usable. That happens whichever drive
    wins and whatever it dispatches to, because otherwise a route the vendor already restored only recovers when
    some later dispatch happens to land on that exact route — which the winning drive here may never choose.

    `dispatch` takes the shape `swarm.run_wave` already expects of a `build_agent`: `(name, model) -> agent`.
    Injecting it is what lets a test exercise every branch here without ever running a real agent; production
    callers may pass one, or leave it unset to use the fleet's own `agents.registry.build_agent`. `probe` is the
    same seam for the reprobe step, independent of `dispatch`.
    """
    root = Path(root)
    moment = now.astimezone(UTC) if now and now.tzinfo else (now.replace(tzinfo=UTC) if now else datetime.now(UTC))

    # ADR-0053 §3: keeping the branch current is not a dispatch action, so it runs before quiet hours can skip
    # anything. Unlike quiet hours, a rebase conflict does not resolve itself - it parks the beat, not any one
    # criterion (nothing has been selected yet at this point), and the loop never resolves the conflict itself.
    sync_conflict = _sync_loop_branch(root)
    if sync_conflict is not None:
        streak = record_rebase_conflict(root)
        if streak >= MAX_REBASE_CONFLICTS_BEFORE_ALERT:
            _alert_rebase_conflict_streak(root, streak, sync_conflict)
        return _finish(
            root, moment, (), None, f"rebase-conflict: {sync_conflict}", None,
            drive=None, drive_deficit=None, sentence="",
        )
    clear_rebase_conflict_streak(root)

    config = load_config(root)

    if moment.hour in config.quiet_hours:
        return _finish(
            root, moment, (), None, f"quiet hours: {moment.hour:02d}:00 UTC is in {config.quiet_hours}", None,
            drive=None, drive_deficit=None, sentence="",
        )

    recovered = availability.reprobe_cooling(root, probe or _default_probe(root), now=moment)
    reprobe_note = f"reprobed and recovered {', '.join(recovered)}; " if recovered else ""

    appetite_config = kshudha.load_config()
    state = kshudha.load_state(root)
    drives = kshudha.measure(root, appetite_config)
    overdue = kshudha.seva_overdue(requests.backlog(root), appetite_config)
    appetite = kshudha.select(drives, state=state, overdue=overdue, config=appetite_config, now=moment)
    kshudha.save_state(root, state)

    sentence = kshudha.sentence(appetite)
    drive_id = appetite.selected
    drives_by_id = {d.id: d for d in appetite.drives}

    if drive_id is None:
        reason = reprobe_note + (appetite.resting_reason or "resting: every drive is satisfied")
        return _finish(root, moment, (), None, reason, None, drive=None, drive_deficit=None, sentence=sentence)

    drive_wire = kshudha.WIRE_NAMES[drive_id]
    drive_deficit = drives_by_id[drive_id].deficit

    effective_id = drive_id
    fallback_note = ""
    if drive_id == "sadhana":
        next_id = _next_eligible(appetite, "sadhana")
        if next_id is None:
            chose, reason, result = _beat_resources(drives_by_id["sadhana"])
            return _finish(
                root, moment, (), chose, reprobe_note + reason, result, drive=drive_wire,
                drive_deficit=drive_deficit, sentence=sentence,
            )
        fallback_note = (
            "resources have the largest eligible deficit but no usable route exists; recording the desire and "
            f"yielding to {kshudha.WIRE_NAMES[next_id]}: "
        )
        effective_id = next_id

    looked_at, chose, reason, result = _dispatch_drive(
        effective_id, root=root, config=config, dispatch=dispatch, drives_by_id=drives_by_id,
    )
    if fallback_note:
        reason = fallback_note + reason
    reason = reprobe_note + reason

    return _finish(
        root, moment, looked_at, chose, reason, result, drive=drive_wire, drive_deficit=drive_deficit,
        sentence=sentence,
    )


__all__ = ["BeatRecord", "GPU_CAPABILITIES", "HeartbeatConfig", "beat", "history", "load_config", "log_path"]
